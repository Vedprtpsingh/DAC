# Library Management System — Spring Boot + MySQL (Exam Prep Project)

A complete, heavily-commented Spring Boot REST API covering the core topics typically tested in Spring Boot / Java backend exams: JPA entities & relationships, Spring Data repositories, service layer with business logic, DTOs, validation, global exception handling, Spring Security with JWT, role-based authorization, pagination, and unit + integration tests.

## Tech Stack
- Java 17, Spring Boot 3.2 (Spring Web, Spring Data JPA, Spring Security)
- MySQL 8 (via `mysql-connector-j`)
- JWT (`io.jsonwebtoken`) for stateless authentication
- Lombok, ModelMapper
- JUnit 5 + Mockito + MockMvc (H2 in-memory DB for tests)
- Maven

## Project Structure
```
src/main/java/com/library/
 ├── LibraryManagementApplication.java   # main entry point
 ├── model/        # JPA entities (Book, Member, BorrowRecord, Category, User)
 ├── repository/    # Spring Data JPA repositories (derived queries + JPQL + native SQL)
 ├── dto/           # Request/Response DTOs + ApiResponse envelope
 ├── service/       # Service interfaces
 ├── serviceImpl/   # Service implementations (business logic, @Transactional)
 ├── controller/    # REST controllers (@RestController)
 ├── security/      # JwtUtil + JwtAuthenticationFilter
 ├── config/        # SecurityConfig, AppConfig, DataInitializer (seed data)
 └── exception/     # Custom exceptions + GlobalExceptionHandler
src/test/java/com/library/
 ├── service/       # Unit tests (Mockito) for BookService & BorrowService
 └── controller/    # Integration tests (MockMvc + @SpringBootTest)
```

## Setup

### 1. Prerequisites
- JDK 17+
- Maven 3.8+
- MySQL Server running locally on port 3306

### 2. Configure database
Edit `src/main/resources/application.properties` if your MySQL username/password differ from `root`/`root`. The database `library_db` is auto-created (`createDatabaseIfNotExist=true`).

### 3. Run
```bash
mvn clean install
mvn spring-boot:run
```
The app starts on `http://localhost:8080`. On first run, `DataInitializer` seeds sample categories, books, members, and three login accounts (printed in the console log):

| Role      | Email                  | Password       |
|-----------|-------------------------|----------------|
| ADMIN     | admin@library.com       | Admin@123      |
| LIBRARIAN | librarian@library.com   | Librarian@123  |
| MEMBER    | john.doe@email.com      | Member@123     |

### 4. Run tests
```bash
mvn test
```
Tests use H2 in-memory DB (`src/test/resources/application.properties`) so no MySQL connection is required to run them.

## API Overview

### Auth (`/api/auth`) — public
- `POST /api/auth/login` — `{ "email": "...", "password": "..." }` → returns JWT
- `GET /api/auth/me` — returns current authenticated user (requires JWT)

### Books (`/api/books`)
- `GET /api/books` — paginated list (public) — `?page=0&size=10&sortBy=title&sortDir=asc`
- `GET /api/books/{id}` — get by id (public)
- `GET /api/books/search?keyword=...` — search title/author/ISBN (public)
- `GET /api/books/available` — only available copies (public)
- `GET /api/books/category/{categoryId}` (public)
- `POST /api/books` — create (LIBRARIAN/ADMIN)
- `PUT /api/books/{id}` — update (LIBRARIAN/ADMIN)
- `DELETE /api/books/{id}` — delete (ADMIN only)

### Members (`/api/members`) — all require LIBRARIAN/ADMIN
- `POST /api/members` — register member
- `GET /api/members/{id}`, `GET /api/members/code/{memberCode}`
- `GET /api/members?page=0&size=10`
- `PUT /api/members/{id}`
- `DELETE /api/members/{id}` (ADMIN only)
- `GET /api/members/search?keyword=...`

### Borrowing (`/api/borrows`) — all require LIBRARIAN/ADMIN
- `POST /api/borrows` — `{ "memberId": 1, "bookId": 1 }`
- `PUT /api/borrows/{id}/return` — return a book, auto-calculates fine if overdue
- `PUT /api/borrows/{id}/pay-fine`
- `GET /api/borrows/{id}`
- `GET /api/borrows/member/{memberId}/history`
- `GET /api/borrows/member/{memberId}?page=0&size=10`
- `GET /api/borrows/overdue`

### Categories (`/api/categories`)
- `GET /api/categories`, `GET /api/categories/{id}` (public)
- `POST /api/categories` (LIBRARIAN/ADMIN)
- `DELETE /api/categories/{id}` (ADMIN)

All responses are wrapped in a standard envelope:
```json
{ "success": true, "message": "...", "data": { ... } }
```

## Using JWT
1. Call `POST /api/auth/login` with valid credentials.
2. Copy the `token` from the response.
3. Send it on subsequent requests: `Authorization: Bearer <token>`

## Exam Topics Covered (see in-code comments for deep explanations)
- `@Entity`, `@Table`, `@Id`, `@GeneratedValue` strategies
- `@OneToMany`, `@ManyToOne`, `@OneToOne` relationships, `mappedBy`, cascade types, fetch types
- `@Enumerated(EnumType.STRING)`, `@Lob`, `@Transient`, `@PrePersist`/`@PreUpdate` lifecycle callbacks
- Spring Data JPA derived query methods, `@Query` (JPQL + native SQL), `@Modifying`, pagination (`Page`, `Pageable`)
- DTO pattern (request/response separation), Bean Validation (`@NotBlank`, `@Email`, `@Pattern`, etc.)
- Service layer with interfaces + impls, `@Transactional` (propagation, readOnly)
- Custom exceptions + `@RestControllerAdvice` / `@ExceptionHandler` global error handling
- Spring Security: `UserDetails`, `UserDetailsService`, `PasswordEncoder` (BCrypt), `SecurityFilterChain`, JWT filter, `@PreAuthorize` method security
- REST controller design: `@RestController`, `@PathVariable`, `@RequestParam`, `@RequestBody`, `ResponseEntity`, proper HTTP status codes
- Testing: Mockito unit tests (`@Mock`, `@InjectMocks`) vs Spring Boot integration tests (`@SpringBootTest`, `MockMvc`, `@WithMockUser`)
- `CommandLineRunner` for data seeding

## Notes
- Default borrow period: 14 days. Fine rate: $0.50/day overdue.
- Borrow limits by membership type: BASIC=2, PREMIUM/STUDENT=5, VIP/STAFF=10.
- This project intentionally favors clarity and exam-relevant comments over micro-optimizations.
