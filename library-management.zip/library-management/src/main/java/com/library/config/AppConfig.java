package com.library.config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * ============================================================
 * GENERAL APPLICATION CONFIGURATION - AppConfig.java
 * ============================================================
 *
 * Demonstrates additional @Bean and @Configuration patterns
 * beyond security (separate file for separation of concerns).
 */
@Configuration
public class AppConfig {

    /**
     * ModelMapper bean - alternative to manual DTO mapping
     * Usage: modelMapper.map(bookEntity, BookResponseDTO.class)
     *
     * Not used by default in this project's services (manual mapping is used
     * for clarity/exam purposes), but available for use/demonstration.
     */
    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    /**
     * CORS CONFIGURATION
     * Cross-Origin Resource Sharing - allows frontend (e.g., React on :3000)
     * to call this API (on :8080) from the browser.
     *
     * WebMvcConfigurer - customize Spring MVC config without @EnableWebMvc
     * (which would disable Spring Boot's auto-configuration)
     */
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**")
                        .allowedOrigins("http://localhost:3000", "http://localhost:5173")
                        .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
}
