package com.library.config;

import com.library.model.*;
import com.library.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * ============================================================
 * DATA INITIALIZER - DataInitializer.java
 * ============================================================
 *
 * CommandLineRunner - Spring Boot interface:
 *   - run(String... args) executes ONCE after application context loads
 *   - Useful for: seeding test data, running startup tasks, scheduled jobs setup
 *
 * Alternative approaches to seed data:
 *   1. CommandLineRunner / ApplicationRunner (this approach - programmatic)
 *   2. data.sql in resources (Spring Boot auto-runs on startup if present)
 *   3. @Sql annotation in tests
 *   4. Flyway/Liquibase migrations (production-grade versioned schema + data)
 *
 * This runs EVERY time the app starts, so we check if data already exists
 * to avoid duplicate inserts (idempotent seeding).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final CategoryRepository categoryRepository;
    private final BookRepository bookRepository;
    private final MemberRepository memberRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        log.info("Checking if seed data is needed...");

        if (categoryRepository.count() > 0) {
            log.info("Data already exists, skipping seeding.");
            return;
        }

        log.info("Seeding initial data...");

        // ===== CATEGORIES =====
        Category fiction = categoryRepository.save(
            Category.builder().name("Fiction").description("Fictional novels and stories").build());
        Category scifi = categoryRepository.save(
            Category.builder().name("Science Fiction").description("Sci-fi and futuristic stories").build());
        Category programming = categoryRepository.save(
            Category.builder().name("Programming").description("Software development and CS books").build());
        Category history = categoryRepository.save(
            Category.builder().name("History").description("Historical books and biographies").build());

        // ===== BOOKS =====
        bookRepository.save(Book.builder()
                .title("Clean Code")
                .author("Robert C. Martin")
                .isbn("9780132350884")
                .publisher("Prentice Hall")
                .publishedDate(LocalDate.of(2008, 8, 1))
                .genre("Programming")
                .category(programming)
                .totalCopies(3)
                .availableCopies(3)
                .price(new BigDecimal("45.99"))
                .description("A handbook of agile software craftsmanship")
                .status(Book.BookStatus.AVAILABLE)
                .build());

        bookRepository.save(Book.builder()
                .title("Effective Java")
                .author("Joshua Bloch")
                .isbn("9780134685991")
                .publisher("Addison-Wesley")
                .publishedDate(LocalDate.of(2017, 12, 27))
                .genre("Programming")
                .category(programming)
                .totalCopies(2)
                .availableCopies(2)
                .price(new BigDecimal("54.99"))
                .description("Best practices for the Java platform")
                .status(Book.BookStatus.AVAILABLE)
                .build());

        bookRepository.save(Book.builder()
                .title("Dune")
                .author("Frank Herbert")
                .isbn("9780441013593")
                .publisher("Ace Books")
                .publishedDate(LocalDate.of(1965, 8, 1))
                .genre("Science Fiction")
                .category(scifi)
                .totalCopies(4)
                .availableCopies(4)
                .price(new BigDecimal("18.50"))
                .description("Epic science fiction novel set on the desert planet Arrakis")
                .status(Book.BookStatus.AVAILABLE)
                .build());

        bookRepository.save(Book.builder()
                .title("1984")
                .author("George Orwell")
                .isbn("9780451524935")
                .publisher("Signet Classics")
                .publishedDate(LocalDate.of(1949, 6, 8))
                .genre("Fiction")
                .category(fiction)
                .totalCopies(5)
                .availableCopies(5)
                .price(new BigDecimal("12.99"))
                .description("Dystopian social science fiction novel")
                .status(Book.BookStatus.AVAILABLE)
                .build());

        bookRepository.save(Book.builder()
                .title("Sapiens")
                .author("Yuval Noah Harari")
                .isbn("9780062316097")
                .publisher("Harper")
                .publishedDate(LocalDate.of(2015, 2, 10))
                .genre("History")
                .category(history)
                .totalCopies(3)
                .availableCopies(3)
                .price(new BigDecimal("24.99"))
                .description("A Brief History of Humankind")
                .status(Book.BookStatus.AVAILABLE)
                .build());

        // ===== MEMBERS =====
        Member member1 = memberRepository.save(Member.builder()
                .memberCode("LIB-2024-0001")
                .firstName("John")
                .lastName("Doe")
                .email("john.doe@email.com")
                .phone("+15551234567")
                .address("123 Main St, Springfield")
                .dateOfBirth(LocalDate.of(1990, 5, 15))
                .status(Member.MemberStatus.ACTIVE)
                .membershipType(Member.MembershipType.PREMIUM)
                .membershipExpiry(LocalDate.now().plusYears(1))
                .outstandingFines(BigDecimal.ZERO)
                .build());

        memberRepository.save(Member.builder()
                .memberCode("LIB-2024-0002")
                .firstName("Jane")
                .lastName("Smith")
                .email("jane.smith@email.com")
                .phone("+15559876543")
                .address("456 Oak Ave, Springfield")
                .dateOfBirth(LocalDate.of(1995, 8, 22))
                .status(Member.MemberStatus.ACTIVE)
                .membershipType(Member.MembershipType.BASIC)
                .membershipExpiry(LocalDate.now().plusYears(1))
                .outstandingFines(BigDecimal.ZERO)
                .build());

        // ===== USERS (for login/authentication) =====
        // ADMIN account
        userRepository.save(User.builder()
                .email("admin@library.com")
                .password(passwordEncoder.encode("Admin@123"))
                .role(User.Role.ROLE_ADMIN)
                .enabled(true)
                .build());

        // LIBRARIAN account
        userRepository.save(User.builder()
                .email("librarian@library.com")
                .password(passwordEncoder.encode("Librarian@123"))
                .role(User.Role.ROLE_LIBRARIAN)
                .enabled(true)
                .build());

        // MEMBER account (linked to John Doe)
        userRepository.save(User.builder()
                .email("john.doe@email.com")
                .password(passwordEncoder.encode("Member@123"))
                .role(User.Role.ROLE_MEMBER)
                .member(member1)
                .enabled(true)
                .build());

        log.info("=================================================");
        log.info("Seed data created successfully!");
        log.info("LOGIN CREDENTIALS FOR TESTING:");
        log.info("  ADMIN:     admin@library.com / Admin@123");
        log.info("  LIBRARIAN: librarian@library.com / Librarian@123");
        log.info("  MEMBER:    john.doe@email.com / Member@123");
        log.info("=================================================");
    }
}
