package com.library.config;

import com.library.repository.UserRepository;
import com.library.security.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * ============================================================
 * SECURITY CONFIGURATION - SecurityConfig.java
 * ============================================================
 *
 * KEY ANNOTATIONS:
 * ----------------
 * @Configuration - Spring processes this class for @Bean definitions
 * @EnableWebSecurity - enables Spring Security's web security support
 * @EnableMethodSecurity - enables method-level security annotations:
 *   @PreAuthorize("hasRole('ADMIN')")
 *   @PostAuthorize("returnObject.username == authentication.name")
 *   @Secured("ROLE_ADMIN")
 *
 * SPRING SECURITY CONCEPTS:
 * --------------------------
 * SecurityFilterChain - defines the security filter pipeline for HTTP requests
 * AuthenticationManager - coordinates authentication (verifies credentials)
 * AuthenticationProvider - actual authentication logic (DaoAuthenticationProvider uses DB)
 * UserDetailsService - loads user from DB during authentication
 * PasswordEncoder - encodes/verifies passwords (BCrypt is standard)
 *
 * HOW @Bean WORKS:
 * Spring calls the @Bean method and stores the return value as a singleton bean.
 * Anywhere you @Autowired that type, Spring injects this instance.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity  // Enables @PreAuthorize, @PostAuthorize on methods
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthFilter;
    private final UserRepository userRepository;

    /**
     * SECURITY FILTER CHAIN
     * Defines which requests are public, which require authentication,
     * and which require specific roles.
     *
     * @param http - HttpSecurity builder for configuring security
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // CSRF (Cross-Site Request Forgery) protection
            // Disable for REST APIs (CSRF is only needed for browser-based form login)
            // JWT is not vulnerable to CSRF (not automatically sent by browsers)
            .csrf(AbstractHttpConfigurer::disable)

            // CORS - configure if frontend is on different domain
            .cors(AbstractHttpConfigurer::disable)  // Enable and configure in production

            // REQUEST AUTHORIZATION RULES
            // Order matters - more specific rules first
            .authorizeHttpRequests(auth -> auth

                // PUBLIC ENDPOINTS - no authentication required
                .requestMatchers("/api/auth/**").permitAll()          // login, register
                .requestMatchers(HttpMethod.GET, "/api/books/**").permitAll()  // Browse books
                .requestMatchers(HttpMethod.GET, "/api/categories/**").permitAll()

                // MEMBER ENDPOINTS - any authenticated user
                .requestMatchers("/api/members/me/**").authenticated()  // own profile

                // LIBRARIAN ENDPOINTS - LIBRARIAN or ADMIN role required
                .requestMatchers("/api/borrows/**").hasAnyRole("LIBRARIAN", "ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/books/**").hasAnyRole("LIBRARIAN", "ADMIN")
                .requestMatchers(HttpMethod.PUT, "/api/books/**").hasAnyRole("LIBRARIAN", "ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/books/**").hasRole("ADMIN")

                // ADMIN ONLY ENDPOINTS
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .requestMatchers("/api/members/**").hasAnyRole("LIBRARIAN", "ADMIN")

                // ALL OTHER requests require authentication
                .anyRequest().authenticated()
            )

            // SESSION MANAGEMENT
            // STATELESS = no server-side session (no HttpSession)
            // Each request must include credentials (JWT token)
            // This is required for JWT-based authentication
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )

            // AUTHENTICATION PROVIDER
            // Tells Spring which AuthenticationProvider to use
            .authenticationProvider(authenticationProvider())

            // JWT FILTER - insert BEFORE the default username/password filter
            // This processes JWT tokens before Spring's built-in form login
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    /**
     * USER DETAILS SERVICE
     * Spring Security calls this to load user during authentication
     *
     * This is a @Bean that returns a UserDetailsService (functional interface)
     * Implemented as a lambda: email → find in DB → return UserDetails
     *
     * UsernameNotFoundException is caught by Spring Security and converted to
     * AuthenticationException (401)
     */
    @Bean
    public UserDetailsService userDetailsService() {
        return username -> userRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
        // Note: User entity implements UserDetails, so it can be returned directly
    }

    /**
     * AUTHENTICATION PROVIDER
     * DaoAuthenticationProvider:
     * - Uses UserDetailsService to load user
     * - Uses PasswordEncoder to verify password
     * - Is the standard provider for username/password auth
     */
    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService());
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    /**
     * AUTHENTICATION MANAGER
     * Coordinates the authentication process
     * AuthenticationManager.authenticate(token) → calls AuthenticationProvider
     *
     * We expose it as a @Bean so AuthController can use it:
     * authManager.authenticate(new UsernamePasswordAuthenticationToken(email, password))
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config)
            throws Exception {
        return config.getAuthenticationManager();
    }

    /**
     * PASSWORD ENCODER
     * BCrypt:
     * - One-way hash function (cannot reverse)
     * - Automatically generates a random salt (prevents rainbow table attacks)
     * - Work factor 10 means 2^10 = 1024 iterations (slow = harder to brute force)
     * - Same password produces different hash each time (due to random salt)
     *
     * Usage:
     *   encoder.encode("password") → "$2a$10$..." (store in DB)
     *   encoder.matches("password", "$2a$10$...") → true/false (verify on login)
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(10);  // 10 = work factor (default)
    }
}
