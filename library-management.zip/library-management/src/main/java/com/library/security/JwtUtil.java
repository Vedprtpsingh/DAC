package com.library.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * ============================================================
 * JWT UTILITY - JwtUtil.java
 * ============================================================
 *
 * JWT = JSON Web Token
 * Structure: header.payload.signature
 *   - Header: {"alg":"HS256","typ":"JWT"} (base64)
 *   - Payload: {"sub":"user@email.com","iat":1234,"exp":5678,...} (base64)
 *   - Signature: HMACSHA256(header+"."+payload, secretKey)
 *
 * Flow:
 *   1. User logs in → JwtUtil.generateToken(userDetails) → returns JWT string
 *   2. Client stores token (localStorage, cookie, etc.)
 *   3. Client sends JWT in header: Authorization: Bearer <token>
 *   4. JwtFilter intercepts request → JwtUtil.validateToken() → sets SecurityContext
 *   5. Controller receives request with authentication context set
 *
 * @Component - makes this a Spring bean (injectable)
 * @Value("${app.jwt.secret}") - injects value from application.properties
 */
@Component
@Slf4j
public class JwtUtil {

    /**
     * @Value - Spring property injection
     * Reads from: app.jwt.secret in application.properties
     */
    @Value("${app.jwt.secret}")
    private String secretKey;

    @Value("${app.jwt.expiration}")
    private long jwtExpiration;

    /**
     * GENERATE TOKEN
     * Creates a JWT with the username as subject
     *
     * @param userDetails - Spring Security user object
     * @return JWT string like "eyJhbGc..."
     */
    public String generateToken(UserDetails userDetails) {
        Map<String, Object> extraClaims = new HashMap<>();
        // Add custom claims (data stored in token payload)
        extraClaims.put("authorities", userDetails.getAuthorities().toString());
        return generateToken(extraClaims, userDetails);
    }

    public String generateToken(Map<String, Object> extraClaims, UserDetails userDetails) {
        return Jwts.builder()
                .setClaims(extraClaims)           // Custom payload data
                .setSubject(userDetails.getUsername())  // Standard claim: "sub"
                .setIssuedAt(new Date())           // Standard claim: "iat"
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration))  // "exp"
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)  // Sign with HMAC-SHA256
                .compact();  // Build and return as compact string
    }

    /**
     * VALIDATE TOKEN
     * Checks:
     * 1. Signature is valid (not tampered)
     * 2. Token is not expired
     * 3. Username matches the userDetails
     */
    public boolean isTokenValid(String token, UserDetails userDetails) {
        try {
            final String username = extractUsername(token);
            return username.equals(userDetails.getUsername()) && !isTokenExpired(token);
        } catch (JwtException e) {
            log.error("JWT validation failed: {}", e.getMessage());
            return false;
        }
    }

    /**
     * EXTRACT USERNAME from token
     * The username (email) is stored in the "sub" (subject) claim
     */
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);  // Claims::getSubject = method reference
    }

    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    /**
     * Generic claim extractor
     * Uses Function<Claims, T> for flexible claim extraction
     *
     * @param <T> return type
     * @param claimsResolver function to extract specific claim
     */
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // ===== PRIVATE HELPERS =====

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    /**
     * Parse and validate the token, returning all claims
     * Throws JwtException if token is invalid or expired
     */
    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())   // Set the key to verify signature
                .build()
                .parseClaimsJws(token)            // Parse and validate
                .getBody();                        // Get payload claims
    }

    /**
     * Convert the secret string to a Key object
     * Keys.hmacShaKeyFor requires the key to be at least 256 bits (32 bytes) for HS256
     */
    private Key getSigningKey() {
        byte[] keyBytes = Decoders.BASE64.decode(
            java.util.Base64.getEncoder().encodeToString(secretKey.getBytes())
        );
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
