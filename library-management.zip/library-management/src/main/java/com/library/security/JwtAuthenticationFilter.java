package com.library.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * ============================================================
 * JWT AUTHENTICATION FILTER
 * ============================================================
 *
 * OncePerRequestFilter - base class that guarantees:
 *   - Filter runs exactly ONCE per HTTP request (not twice for forwards)
 *   - Override doFilterInternal() instead of doFilter()
 *
 * HOW THE FILTER WORKS (per request):
 * 1. Extract "Authorization" header
 * 2. Check it starts with "Bearer "
 * 3. Extract JWT token from header
 * 4. Extract username from token
 * 5. Load user from DB (UserDetailsService)
 * 6. Validate token (signature + expiry + username)
 * 7. Create Authentication object and set in SecurityContext
 * 8. Pass request to next filter (FilterChain)
 *
 * SPRING SECURITY FILTER CHAIN (order matters):
 *   DisableEncodeUrlFilter
 *   SecurityContextPersistenceFilter
 *   HeaderWriterFilter
 *   CsrfFilter
 *   → JwtAuthenticationFilter  ← we insert here
 *   UsernamePasswordAuthenticationFilter
 *   ExceptionTranslationFilter
 *   FilterSecurityInterceptor
 *
 * SecurityContextHolder:
 *   - ThreadLocal storage for the current authenticated user
 *   - Available throughout the request lifecycle
 *   - Cleared after request completes
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException {

        // 1. Get Authorization header
        final String authHeader = request.getHeader("Authorization");
        final String jwt;
        final String userEmail;

        // 2. If no Bearer token, skip authentication (let the next filter handle it)
        //    Public endpoints will not have this header - that's OK
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);  // Pass to next filter
            return;
        }

        // 3. Extract JWT: "Bearer eyJhbGc..." → "eyJhbGc..."
        jwt = authHeader.substring(7);  // Skip "Bearer " (7 chars)

        try {
            // 4. Extract username (email) from JWT payload
            userEmail = jwtUtil.extractUsername(jwt);

            // 5. Only authenticate if:
            //    - Username was extracted from token
            //    - User is NOT already authenticated in this request
            if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {

                // 6. Load user from DB (validates user still exists and is enabled)
                UserDetails userDetails = userDetailsService.loadUserByUsername(userEmail);

                // 7. Validate token (signature + expiry + username match)
                if (jwtUtil.isTokenValid(jwt, userDetails)) {

                    // 8. Create authentication token
                    //    UsernamePasswordAuthenticationToken(principal, credentials, authorities)
                    //    - principal: the user object (UserDetails)
                    //    - credentials: null (we don't need password after authentication)
                    //    - authorities: user's roles/permissions
                    UsernamePasswordAuthenticationToken authToken =
                            new UsernamePasswordAuthenticationToken(
                                    userDetails,
                                    null,
                                    userDetails.getAuthorities()
                            );

                    // Add request details (IP, session ID) to authentication
                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                    // 9. Store authentication in SecurityContext
                    //    This marks the request as AUTHENTICATED
                    //    Controllers can now access the current user via:
                    //    SecurityContextHolder.getContext().getAuthentication()
                    SecurityContextHolder.getContext().setAuthentication(authToken);

                    log.debug("JWT authentication successful for user: {}", userEmail);
                }
            }
        } catch (Exception e) {
            // Invalid JWT: log and continue (request will fail authorization if protected)
            log.error("JWT authentication failed: {}", e.getMessage());
        }

        // 10. Always pass to next filter (whether authenticated or not)
        filterChain.doFilter(request, response);
    }
}
