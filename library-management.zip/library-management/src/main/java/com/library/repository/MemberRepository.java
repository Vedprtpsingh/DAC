package com.library.repository;

import com.library.model.Member;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * MemberRepository - demonstrates Pagination and Optional usage
 *
 * Page<T> findAll(Pageable pageable) → paginated results
 * Pageable is created with: PageRequest.of(pageNum, pageSize, Sort.by("name"))
 */
@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

    Optional<Member> findByEmail(String email);
    Optional<Member> findByMemberCode(String memberCode);

    boolean existsByEmail(String email);
    boolean existsByMemberCode(String memberCode);

    /**
     * PAGINATION: Page<T> with Pageable parameter
     * Generates: SELECT * FROM members WHERE ... LIMIT ? OFFSET ?
     *            SELECT COUNT(*) FROM members WHERE ...  (for total count)
     *
     * The caller provides Pageable: PageRequest.of(0, 10, Sort.by("lastName"))
     */
    Page<Member> findByStatus(Member.MemberStatus status, Pageable pageable);

    /**
     * Dynamic search across multiple fields with pagination
     */
    @Query("SELECT m FROM Member m WHERE " +
           "LOWER(m.firstName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(m.lastName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(m.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "m.memberCode = :keyword")
    Page<Member> searchMembers(@Param("keyword") String keyword, Pageable pageable);

    long countByStatus(Member.MemberStatus status);
}
