package com.library.repository;

import com.library.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * ============================================================
 * REPOSITORY - BookRepository.java
 * ============================================================
 *
 * KEY CONCEPTS:
 * -------------
 * JpaRepository<Entity, IdType> provides:
 *   - save(entity)         → INSERT or UPDATE
 *   - findById(id)         → SELECT WHERE id = ?
 *   - findAll()            → SELECT * FROM table
 *   - delete(entity)       → DELETE FROM table WHERE id = ?
 *   - count()              → SELECT COUNT(*)
 *   - existsById(id)       → SELECT COUNT(*) > 0
 *   - findAll(Pageable)    → paginated SELECT with sorting
 *
 * DERIVED QUERY METHODS (Spring Data JPA auto-generates SQL from method name):
 *   findBy[Field]          → SELECT * WHERE field = ?
 *   findBy[Field]And[Field]→ SELECT * WHERE f1 = ? AND f2 = ?
 *   findBy[Field]Contains  → SELECT * WHERE field LIKE '%?%'
 *   findBy[Field]OrderBy[Field]Desc → SELECT * ORDER BY field DESC
 *   findBy[Field]In(List)  → SELECT * WHERE field IN (...)
 *   countBy[Field]         → SELECT COUNT(*) WHERE field = ?
 *   existsBy[Field]        → SELECT COUNT(*) > 0 WHERE field = ?
 *   deleteBy[Field]        → DELETE WHERE field = ?
 *
 * @Repository - Spring stereotype. Enables exception translation:
 *   DB exceptions (SQLException) → Spring's DataAccessException hierarchy
 *
 * JpaSpecificationExecutor - enables dynamic queries (Specification pattern)
 */
@Repository
public interface BookRepository extends JpaRepository<Book, Long>, JpaSpecificationExecutor<Book> {

    // ===== DERIVED QUERY METHODS =====

    /**
     * Generates: SELECT * FROM books WHERE isbn = ?
     * Returns Optional to avoid NullPointerException
     */
    Optional<Book> findByIsbn(String isbn);

    /**
     * Generates: SELECT * FROM books WHERE title LIKE '%keyword%'
     * IgnoreCase = LOWER(title) LIKE LOWER('%keyword%')
     */
    List<Book> findByTitleContainingIgnoreCase(String title);

    /**
     * Generates: SELECT * FROM books WHERE author LIKE '%author%' AND status = ?
     */
    List<Book> findByAuthorContainingIgnoreCaseAndStatus(String author, Book.BookStatus status);

    /**
     * Generates: SELECT * FROM books WHERE genre = ? AND status = ?
     */
    List<Book> findByGenreAndStatus(String genre, Book.BookStatus status);

    /**
     * Generates: SELECT * FROM books WHERE available_copies > 0
     */
    List<Book> findByAvailableCopiesGreaterThan(Integer copies);

    /**
     * Generates: SELECT * FROM books WHERE category_id = ?
     * Traverses relationship: category is a field, id is a field within it
     */
    List<Book> findByCategoryId(Long categoryId);

    // ===== CUSTOM JPQL QUERIES (@Query) =====
    /**
     * JPQL (Java Persistence Query Language):
     * - Uses entity CLASS names and FIELD names (not table/column names)
     * - "b" is an alias for Book entity
     * - :title is a named parameter (matched with @Param("title"))
     *
     * Equivalent SQL: SELECT * FROM books WHERE LOWER(title) LIKE LOWER('%title%')
     *                             OR LOWER(author) LIKE LOWER('%title%')
     *                             OR isbn = 'title'
     */
    @Query("SELECT b FROM Book b WHERE " +
           "LOWER(b.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(b.author) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "b.isbn = :keyword")
    List<Book> searchBooks(@Param("keyword") String keyword);

    /**
     * JPQL with JOIN:
     * JOIN b.category c → JOIN books with categories table
     * Returns books in a specific category by category name
     */
    @Query("SELECT b FROM Book b JOIN b.category c WHERE LOWER(c.name) = LOWER(:categoryName)")
    List<Book> findByCategoryName(@Param("categoryName") String categoryName);

    /**
     * Native SQL Query (nativeQuery = true):
     * - Uses actual table and column names
     * - Useful for complex SQL not expressible in JPQL
     * - Less portable (DB-specific SQL)
     */
    @Query(value = "SELECT * FROM books WHERE available_copies > 0 ORDER BY title LIMIT :limit",
           nativeQuery = true)
    List<Book> findAvailableBooksNative(@Param("limit") int limit);

    /**
     * @Modifying - required for UPDATE/DELETE JPQL queries (not SELECT)
     * clearAutomatically = true - clears persistence context after update
     *   (prevents stale cached data from being returned)
     *
     * @Transactional is required on the calling service method
     */
    @Modifying(clearAutomatically = true)
    @Query("UPDATE Book b SET b.availableCopies = b.availableCopies - 1 WHERE b.id = :id AND b.availableCopies > 0")
    int decrementAvailableCopies(@Param("id") Long id);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE Book b SET b.availableCopies = b.availableCopies + 1 WHERE b.id = :id")
    int incrementAvailableCopies(@Param("id") Long id);

    /**
     * EXISTS check - more efficient than findBy when we only need boolean
     */
    boolean existsByIsbn(String isbn);

    /**
     * COUNT query
     */
    long countByStatus(Book.BookStatus status);
}
