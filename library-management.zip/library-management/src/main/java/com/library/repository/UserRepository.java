package com.library.repository;

import com.library.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * UserRepository - used by Spring Security for user authentication
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Used by UserDetailsService to load user during login
     * Spring Security calls: userDetailsService.loadUserByUsername(email)
     */
    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);
}
