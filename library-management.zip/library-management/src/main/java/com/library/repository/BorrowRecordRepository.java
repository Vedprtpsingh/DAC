package com.library.repository;

import com.library.model.BorrowRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * BorrowRecordRepository - demonstrates complex JPQL with JOIN, aggregation
 */
@Repository
public interface BorrowRecordRepository extends JpaRepository<BorrowRecord, Long> {

    /**
     * Find active borrow records for a member
     * Demonstrates: relationship traversal (member.id) + enum comparison
     */
    List<BorrowRecord> findByMemberIdAndStatus(Long memberId, BorrowRecord.BorrowStatus status);

    /**
     * Check if a specific book is currently borrowed by a member
     */
    Optional<BorrowRecord> findByMemberIdAndBookIdAndStatus(
        Long memberId, Long bookId, BorrowRecord.BorrowStatus status);

    /**
     * Find all overdue records (due date passed, not returned)
     * Demonstrates: date comparison in JPQL
     */
    @Query("SELECT br FROM BorrowRecord br WHERE " +
           "br.dueDate < :today AND " +
           "br.status = 'BORROWED'")
    List<BorrowRecord> findOverdueRecords(@Param("today") LocalDate today);

    /**
     * Paginated borrow history for a specific member
     * JOIN FETCH → loads member and book in a SINGLE query (avoids N+1 problem)
     *
     * N+1 Problem: fetching 100 borrow records then doing 100 separate queries
     *              for each member/book = 101 total queries
     * JOIN FETCH: 1 query that loads everything together
     */
    @Query("SELECT br FROM BorrowRecord br " +
           "JOIN FETCH br.member m " +
           "JOIN FETCH br.book b " +
           "WHERE m.id = :memberId " +
           "ORDER BY br.borrowDate DESC")
    List<BorrowRecord> findMemberHistoryWithDetails(@Param("memberId") Long memberId);

    /**
     * Aggregate query: count borrows per book
     * Returns Object[] with [bookId, bookTitle, borrowCount]
     */
    @Query("SELECT b.id, b.title, COUNT(br) FROM BorrowRecord br " +
           "JOIN br.book b " +
           "GROUP BY b.id, b.title " +
           "ORDER BY COUNT(br) DESC")
    List<Object[]> findMostBorrowedBooks();

    /**
     * Count active borrows for a member (to check borrowing limit)
     */
    long countByMemberIdAndStatus(Long memberId, BorrowRecord.BorrowStatus status);

    Page<BorrowRecord> findByMemberId(Long memberId, Pageable pageable);

    /**
     * Find records borrowed between dates
     * Between in JPQL = WHERE borrow_date BETWEEN :start AND :end
     */
    List<BorrowRecord> findByBorrowDateBetween(LocalDate startDate, LocalDate endDate);
}
