package com.library.dto;

import lombok.*;

/**
 * Returned after successful login
 * Client stores the JWT token and sends it in future requests:
 * Header: Authorization: Bearer <token>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginResponseDTO {
    private String token;
    private String tokenType = "Bearer";
    private Long userId;
    private String email;
    private String role;
    private long expiresIn;  // milliseconds
}
