package com.library.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.time.LocalDate;

/**
 * BorrowRequestDTO - used for POST /api/borrows (borrowing a book)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BorrowRequestDTO {

    @NotNull(message = "Member ID is required")
    private Long memberId;

    @NotNull(message = "Book ID is required")
    private Long bookId;

    // Optional custom due date; if null, service defaults to 14 days
    private LocalDate dueDate;

    private String notes;
}
