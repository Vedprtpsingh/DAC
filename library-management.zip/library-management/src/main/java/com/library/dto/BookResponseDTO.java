package com.library.dto;

import com.library.model.Book;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * BookResponseDTO - returned from GET endpoints
 *
 * Differences from Book entity:
 * - categoryName (String) instead of Category object (avoids deep nesting)
 * - No borrowRecords list (lazy loaded, not needed in most responses)
 * - No internal JPA metadata
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookResponseDTO {
    private Long id;
    private String title;
    private String author;
    private String isbn;
    private String publisher;
    private LocalDate publishedDate;
    private String genre;
    private Book.BookStatus status;
    private Integer totalCopies;
    private Integer availableCopies;
    private String description;
    private BigDecimal price;
    private Long categoryId;
    private String categoryName;    // Flattened from Category object
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
