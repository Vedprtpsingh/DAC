package com.library.dto;

import jakarta.validation.constraints.*;
import lombok.*;

// =============================================
// LOGIN REQUEST DTO
// =============================================
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequestDTO {

    @NotBlank(message = "Email is required")
    @Email(message = "Valid email required")
    private String email;

    @NotBlank(message = "Password is required")
    private String password;
}
