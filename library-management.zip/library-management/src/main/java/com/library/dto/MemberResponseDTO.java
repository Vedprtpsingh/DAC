package com.library.dto;

import com.library.model.Member;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberResponseDTO {
    private Long id;
    private String memberCode;
    private String firstName;
    private String lastName;
    private String fullName;
    private String email;
    private String phone;
    private String address;
    private Member.MemberStatus status;
    private Member.MembershipType membershipType;
    private LocalDate membershipExpiry;
    private BigDecimal outstandingFines;
    private LocalDateTime createdAt;
    private int activeBorrowCount;
}
