package com.library.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * BookRequestDTO - used for POST /api/books and PUT /api/books/{id}
 *
 * EXAM KEY POINTS:
 * - DTO separates API contract from DB schema
 * - Bean Validation annotations define input rules
 * - @Valid in controller triggers validation of this DTO
 * - Validation errors are caught by @ExceptionHandler(MethodArgumentNotValidException)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookRequestDTO {

    @NotBlank(message = "Title is required")
    @Size(max = 255, message = "Title too long")
    private String title;

    @NotBlank(message = "Author is required")
    private String author;

    @NotBlank(message = "ISBN is required")
    private String isbn;

    private String publisher;

    private LocalDate publishedDate;

    private String genre;

    @Min(value = 1, message = "At least 1 copy required")
    private Integer totalCopies;

    private String description;

    @DecimalMin(value = "0.0", message = "Price must be non-negative")
    private BigDecimal price;

    private Long categoryId;  // FK reference only (not full Category object)
}
