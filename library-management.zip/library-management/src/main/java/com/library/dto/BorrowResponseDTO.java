package com.library.dto;

import com.library.model.BorrowRecord;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BorrowResponseDTO {
    private Long id;
    private Long memberId;
    private String memberName;
    private String memberCode;
    private Long bookId;
    private String bookTitle;
    private String bookIsbn;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private BorrowRecord.BorrowStatus status;
    private BigDecimal fineAmount;
    private Boolean finePaid;
    private boolean overdue;
    private long overdueDays;
    private LocalDateTime createdAt;
}
