package com.library.dto;

import lombok.*;

/**
 * ============================================================
 * GENERIC API RESPONSE WRAPPER
 * ============================================================
 * Wraps all API responses in a standard envelope format.
 *
 * EXAMPLE RESPONSES:
 *
 * Success:
 * {
 *   "success": true,
 *   "message": "Book created successfully",
 *   "data": { "id": 1, "title": "Clean Code", ... }
 * }
 *
 * Error:
 * {
 *   "success": false,
 *   "message": "Book not found",
 *   "data": null
 * }
 *
 * Validation Error:
 * {
 *   "success": false,
 *   "message": "Validation failed",
 *   "errors": {"title": "Title is required", "isbn": "ISBN is required"}
 * }
 *
 * Generic Type <T>: T can be any type (BookResponseDTO, List<BookResponseDTO>, etc.)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApiResponse<T> {

    private boolean success;
    private String message;
    private T data;
    private Object errors;

    // ===== FACTORY METHODS for convenience =====

    /**
     * Create a success response with data
     * Usage: ApiResponse.success(bookDTO, "Book retrieved successfully")
     */
    public static <T> ApiResponse<T> success(T data, String message) {
        return ApiResponse.<T>builder()
                .success(true)
                .message(message)
                .data(data)
                .build();
    }

    /**
     * Create a success response with just a message (no data)
     * Usage: ApiResponse.success("Book deleted successfully")
     */
    public static <T> ApiResponse<T> success(String message) {
        return ApiResponse.<T>builder()
                .success(true)
                .message(message)
                .build();
    }

    /**
     * Create an error response
     * Usage: ApiResponse.error("Book not found")
     */
    public static <T> ApiResponse<T> error(String message) {
        return ApiResponse.<T>builder()
                .success(false)
                .message(message)
                .build();
    }

    /**
     * Create a validation error response
     */
    public static <T> ApiResponse<T> validationError(String message, Object errors) {
        return ApiResponse.<T>builder()
                .success(false)
                .message(message)
                .errors(errors)
                .build();
    }
}
