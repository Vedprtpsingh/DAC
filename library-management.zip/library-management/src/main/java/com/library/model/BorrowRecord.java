package com.library.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * ============================================================
 * ENTITY - BorrowRecord.java
 * ============================================================
 * Represents a borrowing transaction between a Member and a Book
 *
 * EXAM TOPICS COVERED:
 * - @ManyToOne relationships (joining two entities)
 * - @JoinColumn - specifies FK column
 * - Business logic in entity
 * - Calculated/derived fields with @Transient
 * - @PrePersist, @PreUpdate lifecycle callbacks
 */
@Entity
@Table(
    name = "borrow_records",
    indexes = {
        @Index(name = "idx_borrow_member", columnList = "member_id"),
        @Index(name = "idx_borrow_book", columnList = "book_id"),
        @Index(name = "idx_borrow_status", columnList = "status")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BorrowRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * MANY-TO-ONE: Many BorrowRecords → One Member
     *
     * This side OWNS the relationship (has FK column member_id in DB)
     * @JoinColumn(name = "member_id") → column name in borrow_records table
     *
     * fetch = EAGER → load member data immediately with borrow record
     * (Usually safe for @ManyToOne since it's a single object, not a collection)
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "member_id", nullable = false)
    @ToString.Exclude
    private Member member;

    /**
     * MANY-TO-ONE: Many BorrowRecords → One Book
     *
     * optional = false → equivalent to NOT NULL constraint
     */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "book_id", nullable = false)
    @ToString.Exclude
    private Book book;

    @Column(name = "borrow_date", nullable = false)
    private LocalDate borrowDate;

    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    @Column(name = "return_date")
    private LocalDate returnDate;  // NULL if not returned yet

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private BorrowStatus status = BorrowStatus.BORROWED;

    /**
     * Fine calculation:
     * - Late return = overdue days × daily_fine_rate
     * - Stored in DB after return, or calculated on-the-fly
     */
    @Column(name = "fine_amount", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal fineAmount = BigDecimal.ZERO;

    @Column(name = "fine_paid")
    @Builder.Default
    private Boolean finePaid = false;

    @Column(name = "notes", length = 500)
    private String notes;  // Librarian notes (e.g., "Book returned with torn cover")

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // ===== JPA LIFECYCLE CALLBACKS =====
    /**
     * @PrePersist - called just BEFORE the entity is inserted to DB
     * Use for: setting defaults, validation, audit logging
     */
    @PrePersist
    public void prePersist() {
        if (borrowDate == null) {
            borrowDate = LocalDate.now();
        }
        if (dueDate == null) {
            // Default: 14 days borrowing period
            dueDate = borrowDate.plusDays(14);
        }
    }

    /**
     * @PreUpdate - called just BEFORE the entity is updated in DB
     */
    @PreUpdate
    public void preUpdate() {
        // Auto-calculate fine when status changes to RETURNED
        if (BorrowStatus.RETURNED.equals(this.status) && returnDate != null) {
            calculateFine();
        }
    }

    // ===== TRANSIENT (calculated) FIELDS =====
    /**
     * @Transient - field is NOT stored in DB
     * Calculated every time from existing fields
     * Useful for derived/computed values
     */
    @Transient
    public boolean isOverdue() {
        if (BorrowStatus.RETURNED.equals(this.status)) return false;
        return LocalDate.now().isAfter(dueDate);
    }

    @Transient
    public long getOverdueDays() {
        if (!isOverdue()) return 0;
        LocalDate compareDate = returnDate != null ? returnDate : LocalDate.now();
        return ChronoUnit.DAYS.between(dueDate, compareDate);
    }

    // ===== BUSINESS LOGIC =====
    private static final BigDecimal DAILY_FINE_RATE = new BigDecimal("0.50"); // $0.50/day

    public void calculateFine() {
        long overdueDays = getOverdueDays();
        if (overdueDays > 0) {
            this.fineAmount = DAILY_FINE_RATE.multiply(BigDecimal.valueOf(overdueDays));
        } else {
            this.fineAmount = BigDecimal.ZERO;
        }
    }

    // ===== ENUM =====
    public enum BorrowStatus {
        BORROWED,   // Currently borrowed
        RETURNED,   // Returned on time or late
        OVERDUE,    // Not returned and past due date
        LOST        // Reported as lost by member or librarian
    }
}
