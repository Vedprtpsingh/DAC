package com.library.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

/**
 * ============================================================
 * ENTITY - User.java
 * ============================================================
 * Authentication user for the system.
 *
 * EXAM TOPICS COVERED:
 * - Implementing UserDetails interface (Spring Security integration)
 * - @OneToOne relationship (owner side - has FK to Member)
 * - Role-based access control with Enum
 *
 * KEY CONCEPT: UserDetails
 * Spring Security uses this interface to load user info.
 * By implementing it in the entity, we avoid a separate UserDetailsService
 * translation layer (though a service class is still needed).
 */
@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 100)
    @NotBlank
    @Email
    private String email;

    /**
     * Password is stored HASHED (BCrypt) in DB, NEVER plain text
     * BCrypt format: $2a$10$... (algorithm$cost$salt+hash)
     */
    @Column(nullable = false)
    @NotBlank
    private String password;

    /**
     * Role determines what API endpoints the user can access
     * ROLE_ADMIN, ROLE_LIBRARIAN, ROLE_MEMBER
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private Role role = Role.ROLE_MEMBER;

    @Column(nullable = false)
    @Builder.Default
    private boolean enabled = true;

    @Column(name = "account_non_locked")
    @Builder.Default
    private boolean accountNonLocked = true;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    /**
     * ONE-TO-ONE: User → Member (User owns the relationship)
     *
     * @JoinColumn → "member_id" FK column is in the users table
     * This means: users.member_id → members.id
     *
     * optional = true → A User can exist without a Member (admin accounts)
     */
    @OneToOne
    @JoinColumn(name = "member_id", unique = true)
    @ToString.Exclude
    private Member member;

    // ===== UserDetails INTERFACE IMPLEMENTATION =====
    /**
     * getAuthorities() - returns list of roles/permissions for Spring Security
     * SimpleGrantedAuthority wraps the role string
     * Spring Security checks this during authorization
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // Returns: [SimpleGrantedAuthority("ROLE_ADMIN")] or [SimpleGrantedAuthority("ROLE_MEMBER")]
        return List.of(new SimpleGrantedAuthority(role.name()));
    }

    /**
     * Spring Security uses getUsername() to identify the user
     * We use email as the username
     */
    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;  // We don't expire accounts in this system
    }

    @Override
    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    // ===== ROLE ENUM =====
    /**
     * Roles follow Spring Security naming convention: ROLE_ prefix
     * Used in @PreAuthorize("hasRole('ADMIN')") - Spring strips the "ROLE_" prefix
     * Or @PreAuthorize("hasAuthority('ROLE_ADMIN')") - full name required
     */
    public enum Role {
        ROLE_ADMIN,      // Full system access
        ROLE_LIBRARIAN,  // Manage books, process borrows/returns
        ROLE_MEMBER      // View books, see own borrow history
    }
}
