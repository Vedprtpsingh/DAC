package com.library.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

/**
 * ============================================================
 * ENTITY - Category.java
 * ============================================================
 * Book categories/genres (Fiction, Science, History, etc.)
 *
 * EXAM TOPIC: @OneToMany with bidirectional mapping
 */
@Entity
@Table(name = "categories")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 100)
    private String name;  // e.g., "Science Fiction", "Biography"

    @Column(length = 500)
    private String description;

    /**
     * ONE-TO-MANY (inverse side - mappedBy means Category doesn't own the FK)
     * The FK category_id is in the books table
     *
     * orphanRemoval = true → if a Book is removed from this list, it's deleted from DB
     * This is DIFFERENT from CascadeType.REMOVE:
     *   - CascadeType.REMOVE: deleting Category deletes all its Books
     *   - orphanRemoval: removing a Book from category.books list deletes that Book
     */
    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = false)
    @ToString.Exclude
    private List<Book> books;
}
