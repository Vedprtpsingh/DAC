package com.library.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * ============================================================
 * ENTITY CLASS - Book.java
 * ============================================================
 *
 * KEY CONCEPTS:
 * ------------
 * @Entity        - Marks this class as a JPA entity (maps to a DB table)
 * @Table         - Customizes table name and adds constraints
 * @Id            - Marks the primary key field
 * @GeneratedValue - Strategy for auto-generating PK values:
 *    - GenerationType.AUTO     → JPA chooses strategy
 *    - GenerationType.IDENTITY → uses DB AUTO_INCREMENT (MySQL default)
 *    - GenerationType.SEQUENCE → uses DB sequence (PostgreSQL)
 *    - GenerationType.TABLE    → uses a separate PK table
 * @Column        - Maps field to column, can set name/nullable/unique/length
 *
 * LOMBOK ANNOTATIONS:
 * -------------------
 * @Data           = @Getter + @Setter + @ToString + @EqualsAndHashCode + @RequiredArgsConstructor
 * @NoArgsConstructor = generates no-arg constructor (required by JPA)
 * @AllArgsConstructor = generates constructor with all fields
 * @Builder        = enables builder pattern: Book.builder().title("...").build()
 *
 * RELATIONSHIPS (defined here for reference):
 * -------------------------------------------
 * @OneToMany  - One Book → Many BorrowRecords
 * @ManyToOne  - Many Books → One Category
 * @ManyToMany - Books ↔ Authors (bidirectional)
 */
@Entity
@Table(
    name = "books",
    uniqueConstraints = {
        // Composite unique constraint - no two books with same ISBN
        @UniqueConstraint(name = "uk_book_isbn", columnNames = {"isbn"})
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Book {

    /**
     * PRIMARY KEY
     * IDENTITY strategy = MySQL AUTO_INCREMENT
     * Spring Data JPA uses this to determine if entity is new (null = new, not-null = existing)
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * @Column customizations:
     * - nullable = false → NOT NULL constraint in DB
     * - length = 255 → VARCHAR(255)
     *
     * @NotBlank (Bean Validation) → validated at service/controller layer via @Valid
     * Note: JPA constraints are at DB level, Bean Validation at application level
     */
    @Column(nullable = false, length = 255)
    @NotBlank(message = "Title is required")
    @Size(max = 255, message = "Title cannot exceed 255 characters")
    private String title;

    @Column(nullable = false, length = 150)
    @NotBlank(message = "Author is required")
    private String author;

    /**
     * @Column(unique = true) - alternate way to add unique constraint
     * ISBN-13 format: 978-0-306-40615-7
     */
    @Column(unique = true, length = 20)
    @NotBlank(message = "ISBN is required")
    private String isbn;

    @Column(length = 100)
    private String publisher;

    @Column(name = "published_date")
    private LocalDate publishedDate;

    @Column(length = 100)
    private String genre;

    /**
     * @Enumerated(EnumType.STRING) - stores enum as "AVAILABLE" string in DB
     * @Enumerated(EnumType.ORDINAL) - stores enum as 0, 1, 2 (avoid - fragile!)
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default  // Without this, Lombok @Builder ignores field initializer
    private BookStatus status = BookStatus.AVAILABLE;

    @Column(name = "total_copies")
    @Min(value = 1, message = "Must have at least 1 copy")
    @Builder.Default
    private Integer totalCopies = 1;

    @Column(name = "available_copies")
    @Builder.Default
    private Integer availableCopies = 1;

    /**
     * @Lob - maps to TEXT or BLOB column (large object)
     * Use for long text content
     */
    @Lob
    @Column(columnDefinition = "TEXT")
    private String description;

    /**
     * precision = total digits, scale = decimal places
     * BigDecimal is preferred over double for monetary values (exact precision)
     */
    @Column(precision = 10, scale = 2)
    private BigDecimal price;

    /**
     * Audit fields - auto-populated by Hibernate
     * @CreationTimestamp - set once on INSERT
     * @UpdateTimestamp   - updated on every UPDATE
     * updatable = false  - JPA won't update this column after initial insert
     */
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    /**
     * RELATIONSHIP: One Book → Many BorrowRecords
     *
     * @OneToMany(mappedBy = "book") - "book" = field name in BorrowRecord entity
     *    mappedBy tells JPA: "the other side owns this relationship"
     *    The FK column (book_id) is in borrow_records table
     *
     * cascade = CascadeType.ALL - all operations (persist, merge, remove) cascade to children
     * fetch = FetchType.LAZY    - don't load borrowRecords until explicitly accessed
     *    LAZY  = load on demand (preferred for collections)
     *    EAGER = always load with parent (can cause N+1 query problems)
     *
     * @JsonIgnore or @ToString.Exclude - prevents infinite recursion in bidirectional relations
     */
    @OneToMany(mappedBy = "book", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @ToString.Exclude  // Prevent infinite loop in toString()
    private List<BorrowRecord> borrowRecords;

    /**
     * RELATIONSHIP: Many Books → One Category
     *
     * @ManyToOne - FK is on this side (books table has category_id column)
     * fetch = EAGER - load category with book (OK for single objects)
     * @JoinColumn - specifies the FK column name
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id")
    private Category category;

    // ===== ENUM DEFINITION (can also be in its own file) =====
    /**
     * Book availability status
     * Store as STRING in DB for readability
     */
    public enum BookStatus {
        AVAILABLE,    // Book is on shelf
        BORROWED,     // All copies are borrowed
        RESERVED,     // Book is reserved
        LOST,         // Book is reported lost
        MAINTENANCE   // Book is under maintenance/repair
    }
}
