package com.library.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * ============================================================
 * ENTITY - Member.java
 * ============================================================
 * Represents a library member (user who borrows books)
 *
 * EXAM TOPICS COVERED:
 * - @Entity, @Table with indexes
 * - Field-level constraints (@Email, @Pattern, @Size)
 * - @OneToMany relationship
 * - @OneToOne relationship
 * - Enum with @Enumerated
 * - Audit timestamps
 */
@Entity
@Table(
    name = "members",
    indexes = {
        // DB index on email for faster lookups
        @Index(name = "idx_member_email", columnList = "email"),
        @Index(name = "idx_member_phone", columnList = "phone")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Member ID card number - unique identifier used at library counter
     * @Column(name = ...) maps Java field name to different DB column name
     */
    @Column(name = "member_code", unique = true, nullable = false, length = 20)
    @NotBlank(message = "Member code is required")
    private String memberCode;

    @Column(name = "first_name", nullable = false, length = 80)
    @NotBlank(message = "First name is required")
    @Size(min = 2, max = 80)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 80)
    @NotBlank(message = "Last name is required")
    private String lastName;

    /**
     * @Email - validates email format using Bean Validation
     * Checks for basic format: localpart@domain.tld
     */
    @Column(unique = true, nullable = false, length = 150)
    @Email(message = "Must be a valid email address")
    @NotBlank(message = "Email is required")
    private String email;

    /**
     * @Pattern - validates using regular expression
     * This regex: optional +, then 7-15 digits
     */
    @Column(length = 20)
    @Pattern(regexp = "^\\+?[0-9]{7,15}$", message = "Invalid phone number format")
    private String phone;

    @Column(length = 255)
    private String address;

    @Column(name = "date_of_birth")
    @Past(message = "Date of birth must be in the past")
    private LocalDate dateOfBirth;

    /**
     * Membership status enum
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private MemberStatus status = MemberStatus.ACTIVE;

    /**
     * Membership type - determines borrowing limits
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "membership_type", nullable = false)
    @Builder.Default
    private MembershipType membershipType = MembershipType.BASIC;

    @Column(name = "membership_expiry")
    private LocalDate membershipExpiry;

    /**
     * Fine amount owed by member
     * BigDecimal for precise monetary calculations
     */
    @Column(name = "outstanding_fines", precision = 10, scale = 2)
    @Builder.Default
    private java.math.BigDecimal outstandingFines = java.math.BigDecimal.ZERO;

    /**
     * ONE-TO-ONE relationship with User (for login)
     *
     * @OneToOne(mappedBy = "member") - User entity owns this relationship
     *   (User table has member_id FK column)
     * cascade = CascadeType.ALL - if Member is deleted, associated User is also deleted
     */
    @OneToOne(mappedBy = "member", cascade = CascadeType.ALL)
    @ToString.Exclude
    private User user;

    /**
     * ONE-TO-MANY: One Member → Many BorrowRecords
     * mappedBy = "member" - field name in BorrowRecord
     */
    @OneToMany(mappedBy = "member", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @ToString.Exclude
    private List<BorrowRecord> borrowRecords;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // ===== HELPER METHODS =====
    /**
     * Transient method - NOT persisted to DB
     * Useful utility in entity
     */
    @Transient  // @Transient = exclude from JPA persistence
    public String getFullName() {
        return firstName + " " + lastName;
    }

    @Transient
    public boolean isActive() {
        return MemberStatus.ACTIVE.equals(this.status);
    }

    // ===== ENUMS =====
    public enum MemberStatus {
        ACTIVE,
        INACTIVE,
        SUSPENDED,  // Has unpaid fines or violations
        EXPIRED     // Membership expired
    }

    public enum MembershipType {
        BASIC,      // Can borrow 2 books
        PREMIUM,    // Can borrow 5 books
        VIP,        // Can borrow 10 books
        STUDENT,    // Special student membership
        STAFF       // Library staff membership
    }
}
