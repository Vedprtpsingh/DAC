package com.library.controller;

import com.library.dto.ApiResponse;
import com.library.dto.LoginRequestDTO;
import com.library.dto.LoginResponseDTO;
import com.library.security.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

/**
 * ============================================================
 * AUTH CONTROLLER - AuthController.java
 * ============================================================
 *
 * Handles login and registration.
 *
 * LOGIN FLOW:
 * 1. POST /api/auth/login with {email, password}
 * 2. authManager.authenticate() → calls DaoAuthenticationProvider
 *    → UserDetailsService.loadUserByUsername(email)
 *    → PasswordEncoder.matches(raw, encoded)
 * 3. If valid → generate JWT token
 * 4. Return token to client
 *
 * AUTHENTICATION vs AUTHORIZATION:
 *   Authentication = WHO are you? (login)
 *   Authorization  = WHAT can you do? (role check)
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    /**
     * LOGIN
     * URL: POST /api/auth/login
     * Public endpoint (no auth required)
     *
     * authManager.authenticate() throws:
     *   - BadCredentialsException if password wrong → 401
     *   - DisabledException if account disabled → 401
     *   - LockedException if account locked → 401
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponseDTO>> login(
            @Valid @RequestBody LoginRequestDTO loginRequest) {

        log.info("Login attempt for: {}", loginRequest.getEmail());

        // This internally calls UserDetailsService + PasswordEncoder
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getEmail(),
                        loginRequest.getPassword()
                )
        );

        // Authentication succeeded - generate JWT
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String token = jwtUtil.generateToken(userDetails);

        LoginResponseDTO response = LoginResponseDTO.builder()
                .token(token)
                .tokenType("Bearer")
                .email(userDetails.getUsername())
                .role(userDetails.getAuthorities().iterator().next().getAuthority())
                .expiresIn(86400000L)  // 24 hours
                .build();

        log.info("Login successful for: {}", loginRequest.getEmail());
        return ResponseEntity.ok(ApiResponse.success(response, "Login successful"));
    }

    /**
     * TEST endpoint to verify token works
     * URL: GET /api/auth/me
     * Requires: valid JWT in Authorization header
     */
    @GetMapping("/me")
    public ResponseEntity<ApiResponse<String>> getCurrentUser(
            org.springframework.security.core.Authentication authentication) {
        // Spring MVC injects the current authentication from SecurityContext
        return ResponseEntity.ok(
            ApiResponse.success(authentication.getName(), "Current user retrieved")
        );
    }
}
