package com.library.controller;

import com.library.dto.ApiResponse;
import com.library.dto.MemberRequestDTO;
import com.library.dto.MemberResponseDTO;
import com.library.service.MemberService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * ============================================================
 * REST CONTROLLER - MemberController.java
 * ============================================================
 * CRUD endpoints for library members.
 * Most endpoints restricted to LIBRARIAN/ADMIN since members
 * shouldn't be able to browse/edit other members' data.
 */
@RestController
@RequestMapping("/api/members")
@RequiredArgsConstructor
@Slf4j
public class MemberController {

    private final MemberService memberService;

    /**
     * CREATE MEMBER
     * URL: POST /api/members
     * Open to LIBRARIAN/ADMIN (front-desk registration)
     */
    @PostMapping
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<MemberResponseDTO>> createMember(
            @Valid @RequestBody MemberRequestDTO requestDTO) {

        MemberResponseDTO member = memberService.createMember(requestDTO);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(member, "Member registered successfully"));
    }

    /**
     * GET MEMBER BY ID
     * URL: GET /api/members/5
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<MemberResponseDTO>> getMemberById(@PathVariable Long id) {
        MemberResponseDTO member = memberService.getMemberById(id);
        return ResponseEntity.ok(ApiResponse.success(member, "Member retrieved successfully"));
    }

    /**
     * GET MEMBER BY CODE
     * URL: GET /api/members/code/LIB-2024-0001
     */
    @GetMapping("/code/{memberCode}")
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<MemberResponseDTO>> getMemberByCode(
            @PathVariable String memberCode) {
        MemberResponseDTO member = memberService.getMemberByCode(memberCode);
        return ResponseEntity.ok(ApiResponse.success(member, "Member retrieved successfully"));
    }

    /**
     * GET ALL MEMBERS (paginated)
     * URL: GET /api/members?page=0&size=10
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<Page<MemberResponseDTO>>> getAllMembers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<MemberResponseDTO> members = memberService.getAllMembers(pageable);
        return ResponseEntity.ok(ApiResponse.success(members, "Members retrieved successfully"));
    }

    /**
     * UPDATE MEMBER
     * URL: PUT /api/members/5
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<MemberResponseDTO>> updateMember(
            @PathVariable Long id,
            @Valid @RequestBody MemberRequestDTO requestDTO) {

        MemberResponseDTO updated = memberService.updateMember(id, requestDTO);
        return ResponseEntity.ok(ApiResponse.success(updated, "Member updated successfully"));
    }

    /**
     * DELETE MEMBER
     * URL: DELETE /api/members/5
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteMember(@PathVariable Long id) {
        memberService.deleteMember(id);
        return ResponseEntity
                .status(HttpStatus.NO_CONTENT)
                .body(ApiResponse.success("Member deleted successfully"));
    }

    /**
     * SEARCH MEMBERS
     * URL: GET /api/members/search?keyword=john&page=0&size=10
     */
    @GetMapping("/search")
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<Page<MemberResponseDTO>>> searchMembers(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<MemberResponseDTO> members = memberService.searchMembers(keyword, pageable);
        return ResponseEntity.ok(ApiResponse.success(members, "Search results retrieved"));
    }
}
