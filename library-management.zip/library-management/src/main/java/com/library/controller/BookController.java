package com.library.controller;

import com.library.dto.ApiResponse;
import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import com.library.service.BookService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * ============================================================
 * REST CONTROLLER - BookController.java
 * ============================================================
 *
 * KEY ANNOTATIONS:
 * ----------------
 * @RestController = @Controller + @ResponseBody
 *   - @Controller: marks as Spring MVC controller, component-scanned
 *   - @ResponseBody: all methods return JSON (not view names)
 *
 * @RequestMapping("/api/books") - base URL for all methods in this class
 *
 * HTTP METHOD ANNOTATIONS:
 *   @GetMapping    → HTTP GET     (read)
 *   @PostMapping   → HTTP POST    (create)
 *   @PutMapping    → HTTP PUT     (full update)
 *   @PatchMapping  → HTTP PATCH   (partial update)
 *   @DeleteMapping → HTTP DELETE  (delete)
 *
 * PARAMETER ANNOTATIONS:
 *   @PathVariable  - from URL path: /api/books/{id}
 *   @RequestParam  - from query string: /api/books?keyword=java
 *   @RequestBody   - from HTTP request body (JSON → DTO)
 *   @RequestHeader - from HTTP headers
 *   @Valid         - triggers Bean Validation on the annotated object
 *
 * ResponseEntity<T>:
 *   - Wraps response with HTTP status code, headers, and body
 *   - ResponseEntity.ok(body)                 → 200 OK
 *   - ResponseEntity.created(uri).body(body)  → 201 Created
 *   - ResponseEntity.noContent().build()      → 204 No Content
 *   - ResponseEntity.status(HttpStatus.X).body(body) → custom status
 *
 * @PreAuthorize - method-level security (requires @EnableMethodSecurity in config)
 *   hasRole('ADMIN')    → user must have ROLE_ADMIN
 *   hasAnyRole(...)     → any of the listed roles
 *   isAuthenticated()   → just needs to be logged in
 *   #id == principal.id → SpEL: compare path var to current user's id
 *
 * REST API DESIGN (CRUD):
 *   GET    /api/books         → list all (paginated)
 *   POST   /api/books         → create new
 *   GET    /api/books/{id}    → get by id
 *   PUT    /api/books/{id}    → update
 *   DELETE /api/books/{id}    → delete
 *   GET    /api/books/search  → search
 */
@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
@Slf4j
public class BookController {

    // Constructor injection of service (interface, not implementation)
    private final BookService bookService;

    /**
     * GET ALL BOOKS - paginated
     *
     * URL: GET /api/books?page=0&size=10&sort=title,asc
     *
     * @RequestParam(defaultValue = "0") - optional query param with default
     * Pageable: Spring MVC auto-creates from request params
     *
     * Response body example:
     * {
     *   "content": [...],
     *   "pageable": {...},
     *   "totalPages": 5,
     *   "totalElements": 47
     * }
     */
    @GetMapping
    public ResponseEntity<ApiResponse<Page<BookResponseDTO>>> getAllBooks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        // Build Pageable manually (alternative to Spring's auto-resolution)
        Sort sort = sortDir.equalsIgnoreCase("desc") ?
                Sort.by(sortBy).descending() :
                Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<BookResponseDTO> books = bookService.getAllBooks(pageable);
        return ResponseEntity.ok(ApiResponse.success(books, "Books retrieved successfully"));
    }

    /**
     * GET BOOK BY ID
     * URL: GET /api/books/5
     *
     * @PathVariable - maps {id} from URL to method parameter
     * If not found, service throws ResourceNotFoundException → GlobalExceptionHandler returns 404
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<BookResponseDTO>> getBookById(@PathVariable Long id) {
        BookResponseDTO book = bookService.getBookById(id);
        return ResponseEntity.ok(ApiResponse.success(book, "Book retrieved successfully"));
    }

    /**
     * CREATE BOOK
     * URL: POST /api/books
     * Body: BookRequestDTO JSON
     *
     * @RequestBody - deserializes JSON body → BookRequestDTO object
     * @Valid - validates BookRequestDTO fields (@NotBlank, @Size, etc.)
     *          If validation fails → MethodArgumentNotValidException → 400 response
     *
     * @PreAuthorize - requires LIBRARIAN or ADMIN role
     *
     * Returns 201 Created (not 200 OK)
     */
    @PostMapping
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<BookResponseDTO>> createBook(
            @Valid @RequestBody BookRequestDTO requestDTO) {

        log.info("Request to create book: {}", requestDTO.getTitle());
        BookResponseDTO book = bookService.createBook(requestDTO);

        // 201 Created with Location header is REST best practice for POST
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(book, "Book created successfully"));
    }

    /**
     * UPDATE BOOK
     * URL: PUT /api/books/5
     * Body: BookRequestDTO JSON (full replacement)
     *
     * PUT = replace entire resource (all fields required)
     * PATCH = partial update (only changed fields)
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")
    public ResponseEntity<ApiResponse<BookResponseDTO>> updateBook(
            @PathVariable Long id,
            @Valid @RequestBody BookRequestDTO requestDTO) {

        BookResponseDTO updated = bookService.updateBook(id, requestDTO);
        return ResponseEntity.ok(ApiResponse.success(updated, "Book updated successfully"));
    }

    /**
     * DELETE BOOK
     * URL: DELETE /api/books/5
     *
     * Returns 204 No Content (no body needed for delete)
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return ResponseEntity
                .status(HttpStatus.NO_CONTENT)
                .body(ApiResponse.success("Book deleted successfully"));
    }

    /**
     * SEARCH BOOKS
     * URL: GET /api/books/search?keyword=java
     *
     * @RequestParam - reads "keyword" from query string
     * required = true (default) - returns 400 if missing
     * required = false - optional parameter (value will be null if missing)
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<BookResponseDTO>>> searchBooks(
            @RequestParam String keyword) {

        List<BookResponseDTO> books = bookService.searchBooks(keyword);
        return ResponseEntity.ok(ApiResponse.success(books,
                String.format("Found %d books matching '%s'", books.size(), keyword)));
    }

    /**
     * GET AVAILABLE BOOKS
     * URL: GET /api/books/available
     */
    @GetMapping("/available")
    public ResponseEntity<ApiResponse<List<BookResponseDTO>>> getAvailableBooks() {
        List<BookResponseDTO> books = bookService.getAvailableBooks();
        return ResponseEntity.ok(ApiResponse.success(books, "Available books retrieved"));
    }

    /**
     * GET BOOKS BY CATEGORY
     * URL: GET /api/books/category/3
     */
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<ApiResponse<List<BookResponseDTO>>> getBooksByCategory(
            @PathVariable Long categoryId) {

        List<BookResponseDTO> books = bookService.getBooksByCategory(categoryId);
        return ResponseEntity.ok(ApiResponse.success(books, "Books in category retrieved"));
    }
}
