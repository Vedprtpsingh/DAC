package com.library.controller;

import com.library.dto.ApiResponse;
import com.library.dto.BorrowRequestDTO;
import com.library.dto.BorrowResponseDTO;
import com.library.service.BorrowService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * ============================================================
 * REST CONTROLLER - BorrowController.java
 * ============================================================
 * Handles book borrowing and returning operations.
 * Restricted to LIBRARIAN/ADMIN (front-desk operations).
 *
 * Demonstrates a typical "transactional workflow" API:
 * borrow → return → pay fine
 */
@RestController
@RequestMapping("/api/borrows")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasAnyRole('LIBRARIAN', 'ADMIN')")  // Class-level: applies to ALL methods
public class BorrowController {

    private final BorrowService borrowService;

    /**
     * BORROW A BOOK
     * URL: POST /api/borrows
     * Body: { "memberId": 1, "bookId": 5, "notes": "..." }
     */
    @PostMapping
    public ResponseEntity<ApiResponse<BorrowResponseDTO>> borrowBook(
            @Valid @RequestBody BorrowRequestDTO requestDTO) {

        BorrowResponseDTO record = borrowService.borrowBook(requestDTO);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(record, "Book borrowed successfully"));
    }

    /**
     * RETURN A BOOK
     * URL: PUT /api/borrows/{id}/return
     *
     * Using PUT here since we're updating the resource's state (not creating new)
     * Some APIs use POST for "actions" like this - both are acceptable patterns
     */
    @PutMapping("/{id}/return")
    public ResponseEntity<ApiResponse<BorrowResponseDTO>> returnBook(@PathVariable Long id) {
        BorrowResponseDTO record = borrowService.returnBook(id);

        String message = record.getFineAmount().compareTo(java.math.BigDecimal.ZERO) > 0
                ? String.format("Book returned with a fine of $%s", record.getFineAmount())
                : "Book returned successfully";

        return ResponseEntity.ok(ApiResponse.success(record, message));
    }

    /**
     * PAY FINE
     * URL: PUT /api/borrows/{id}/pay-fine
     */
    @PutMapping("/{id}/pay-fine")
    public ResponseEntity<ApiResponse<BorrowResponseDTO>> payFine(@PathVariable Long id) {
        BorrowResponseDTO record = borrowService.payFine(id);
        return ResponseEntity.ok(ApiResponse.success(record, "Fine paid successfully"));
    }

    /**
     * GET BORROW RECORD BY ID
     * URL: GET /api/borrows/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<BorrowResponseDTO>> getBorrowById(@PathVariable Long id) {
        BorrowResponseDTO record = borrowService.getBorrowById(id);
        return ResponseEntity.ok(ApiResponse.success(record, "Borrow record retrieved"));
    }

    /**
     * GET MEMBER'S FULL BORROW HISTORY
     * URL: GET /api/borrows/member/{memberId}/history
     */
    @GetMapping("/member/{memberId}/history")
    public ResponseEntity<ApiResponse<List<BorrowResponseDTO>>> getMemberHistory(
            @PathVariable Long memberId) {

        List<BorrowResponseDTO> history = borrowService.getMemberBorrowHistory(memberId);
        return ResponseEntity.ok(ApiResponse.success(history, "Borrow history retrieved"));
    }

    /**
     * GET MEMBER'S BORROWS (PAGINATED)
     * URL: GET /api/borrows/member/{memberId}?page=0&size=10
     */
    @GetMapping("/member/{memberId}")
    public ResponseEntity<ApiResponse<Page<BorrowResponseDTO>>> getMemberBorrows(
            @PathVariable Long memberId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<BorrowResponseDTO> borrows = borrowService.getMemberBorrows(memberId, pageable);
        return ResponseEntity.ok(ApiResponse.success(borrows, "Borrow records retrieved"));
    }

    /**
     * GET ALL OVERDUE RECORDS
     * URL: GET /api/borrows/overdue
     * Useful for librarian dashboard - books that need follow-up
     */
    @GetMapping("/overdue")
    public ResponseEntity<ApiResponse<List<BorrowResponseDTO>>> getOverdueRecords() {
        List<BorrowResponseDTO> overdue = borrowService.getOverdueRecords();
        return ResponseEntity.ok(ApiResponse.success(overdue,
                String.format("%d overdue records found", overdue.size())));
    }
}
