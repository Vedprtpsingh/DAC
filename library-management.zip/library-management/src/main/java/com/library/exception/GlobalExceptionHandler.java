package com.library.exception;

import com.library.dto.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * ============================================================
 * GLOBAL EXCEPTION HANDLER
 * ============================================================
 *
 * @RestControllerAdvice = @ControllerAdvice + @ResponseBody
 *   - @ControllerAdvice: applies to all @Controller classes (AOP-like)
 *   - @ResponseBody: all return values serialized to JSON
 *
 * @ExceptionHandler(ExceptionType.class):
 *   - Intercepts specific exceptions thrown anywhere in the app
 *   - Returns structured error response instead of Spring's default error page
 *   - Prevents stack traces from leaking to client
 *
 * METHOD SIGNATURE: Can accept various parameters:
 *   - Exception ex          → the caught exception
 *   - HttpServletRequest    → request details
 *   - WebRequest            → abstraction over request
 *   - HttpStatus            → response status
 *
 * RETURN TYPE: ResponseEntity<ApiResponse<?>>
 *   - ResponseEntity wraps response body + HTTP status + headers
 *   - new ResponseEntity<>(body, HttpStatus.NOT_FOUND) → 404 with body
 *
 * @Slf4j: Lombok generates: private static final Logger log = LoggerFactory.getLogger(...)
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * Handle @Valid / @Validated validation failures
     * Triggered when DTO fields fail Bean Validation constraints
     *
     * MethodArgumentNotValidException contains all field errors
     * We extract them into a Map<fieldName, errorMessage>
     *
     * HTTP 400 Bad Request
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<?>> handleValidationException(
            MethodArgumentNotValidException ex, WebRequest request) {

        log.warn("Validation failed: {}", ex.getMessage());

        // Extract all field-level errors into a map
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            // Cast to FieldError to get field name
            String fieldName = ((FieldError) error).getField();
            String message = error.getDefaultMessage();
            errors.put(fieldName, message);
        });

        ApiResponse<?> response = ApiResponse.validationError("Validation failed", errors);
        return ResponseEntity.badRequest().body(response);
    }

    /**
     * Handle resource not found (404)
     * Thrown by: bookRepository.findById().orElseThrow(ResourceNotFoundException::new)
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiResponse<?>> handleResourceNotFoundException(
            ResourceNotFoundException ex) {

        log.warn("Resource not found: {}", ex.getMessage());
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(ApiResponse.error(ex.getMessage()));
    }

    /**
     * Handle duplicate resource (409 Conflict)
     * Thrown when: creating book with duplicate ISBN, member with duplicate email
     */
    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<ApiResponse<?>> handleDuplicateResourceException(
            DuplicateResourceException ex) {

        log.warn("Duplicate resource: {}", ex.getMessage());
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(ApiResponse.error(ex.getMessage()));
    }

    /**
     * Handle business rule violations (400 Bad Request)
     * Thrown when: book not available, member exceeded limit, returning unreturned book
     */
    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ApiResponse<?>> handleBusinessException(BusinessException ex) {
        log.warn("Business rule violation: {}", ex.getMessage());
        return ResponseEntity
                .badRequest()
                .body(ApiResponse.error(ex.getMessage()));
    }

    /**
     * Handle Spring Security access denied (403 Forbidden)
     * Thrown when: authenticated user lacks required role
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponse<?>> handleAccessDeniedException(AccessDeniedException ex) {
        log.warn("Access denied: {}", ex.getMessage());
        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(ApiResponse.error("You do not have permission to perform this action"));
    }

    /**
     * Handle bad login credentials (401 Unauthorized)
     */
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ApiResponse<?>> handleBadCredentialsException(BadCredentialsException ex) {
        return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(ApiResponse.error("Invalid email or password"));
    }

    /**
     * Catch-all: handles any unhandled exceptions (500 Internal Server Error)
     * IMPORTANT: Log the full stack trace here, but return a generic message to client
     * Never expose internal error details/stack traces to the client!
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<?>> handleGenericException(Exception ex, WebRequest request) {
        // Log full stack trace internally
        log.error("Unexpected error occurred: {}", ex.getMessage(), ex);

        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiResponse.error("An internal error occurred. Please try again later."));
    }
}
