package com.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ============================================================
 * MAIN ENTRY POINT - LibraryManagementApplication.java
 * ============================================================
 *
 * @SpringBootApplication is a COMBO annotation that includes:
 *   1. @Configuration       - marks this as a config source (Spring bean definitions)
 *   2. @EnableAutoConfiguration - tells Spring Boot to auto-configure beans
 *      based on classpath (e.g., sees mysql-connector → configures DataSource)
 *   3. @ComponentScan       - scans this package and sub-packages for
 *      @Component, @Service, @Repository, @Controller, etc.
 *
 * SpringApplication.run() bootstraps the application:
 *   - Creates ApplicationContext
 *   - Starts embedded Tomcat server
 *   - Initializes all beans
 */
@SpringBootApplication
public class LibraryManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementApplication.class, args);
        System.out.println("=== Library Management System Started! ===");
        System.out.println("API available at: http://localhost:8080/api");
    }
}
