package com.library.service;

import com.library.dto.BorrowRequestDTO;
import com.library.dto.BorrowResponseDTO;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface BorrowService {
    BorrowResponseDTO borrowBook(BorrowRequestDTO requestDTO);
    BorrowResponseDTO returnBook(Long borrowRecordId);
    BorrowResponseDTO getBorrowById(Long id);
    List<BorrowResponseDTO> getMemberBorrowHistory(Long memberId);
    List<BorrowResponseDTO> getOverdueRecords();
    BorrowResponseDTO payFine(Long borrowRecordId);
    Page<BorrowResponseDTO> getMemberBorrows(Long memberId, Pageable pageable);
}
