package com.library.service;

import com.library.dto.MemberRequestDTO;
import com.library.dto.MemberResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface MemberService {
    MemberResponseDTO createMember(MemberRequestDTO requestDTO);
    MemberResponseDTO getMemberById(Long id);
    MemberResponseDTO getMemberByCode(String memberCode);
    Page<MemberResponseDTO> getAllMembers(Pageable pageable);
    MemberResponseDTO updateMember(Long id, MemberRequestDTO requestDTO);
    void deleteMember(Long id);
    Page<MemberResponseDTO> searchMembers(String keyword, Pageable pageable);
}
