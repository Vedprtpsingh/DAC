package com.library.service;

import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * ============================================================
 * SERVICE INTERFACE - BookService.java
 * ============================================================
 *
 * WHY USE AN INTERFACE?
 * ---------------------
 * 1. ABSTRACTION: Controller depends on interface, not implementation
 *    → Easy to swap implementations (e.g., mock for testing)
 * 2. SPRING AOP: @Transactional and other AOP advice work on interfaces
 *    (Spring creates a proxy around the interface, not the concrete class)
 * 3. TESTABILITY: Easy to mock with Mockito: when(bookService.findById(...))
 * 4. DESIGN PRINCIPLE: "Program to interfaces, not implementations" (OCP)
 *
 * NAMING CONVENTION:
 * - Interface: BookService
 * - Implementation: BookServiceImpl (in serviceImpl package)
 *
 * EXAM TIP: The service layer contains BUSINESS LOGIC.
 * Controllers handle HTTP, Repositories handle DB, Services handle logic.
 */
public interface BookService {

    /**
     * Create a new book
     * @param requestDTO validated input from controller
     * @return created book as DTO
     * @throws com.library.exception.DuplicateResourceException if ISBN exists
     */
    BookResponseDTO createBook(BookRequestDTO requestDTO);

    /**
     * Get book by ID
     * @throws com.library.exception.ResourceNotFoundException if not found
     */
    BookResponseDTO getBookById(Long id);

    /**
     * Get all books with pagination
     * @param pageable contains page number, page size, sort direction
     * @return Page<BookResponseDTO> with metadata (totalElements, totalPages, etc.)
     */
    Page<BookResponseDTO> getAllBooks(Pageable pageable);

    /**
     * Update an existing book
     * @throws com.library.exception.ResourceNotFoundException if book not found
     */
    BookResponseDTO updateBook(Long id, BookRequestDTO requestDTO);

    /**
     * Delete book by ID (soft delete or hard delete)
     */
    void deleteBook(Long id);

    /**
     * Search books by keyword (title, author, or ISBN)
     */
    List<BookResponseDTO> searchBooks(String keyword);

    /**
     * Get books by category
     */
    List<BookResponseDTO> getBooksByCategory(Long categoryId);

    /**
     * Get all available books (not borrowed)
     */
    List<BookResponseDTO> getAvailableBooks();
}
