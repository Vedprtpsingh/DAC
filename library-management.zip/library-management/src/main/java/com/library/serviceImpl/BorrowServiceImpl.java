package com.library.serviceImpl;

import com.library.dto.BorrowRequestDTO;
import com.library.dto.BorrowResponseDTO;
import com.library.exception.BusinessException;
import com.library.exception.ResourceNotFoundException;
import com.library.model.Book;
import com.library.model.BorrowRecord;
import com.library.model.Member;
import com.library.repository.BookRepository;
import com.library.repository.BorrowRecordRepository;
import com.library.repository.MemberRepository;
import com.library.service.BorrowService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ============================================================
 * SERVICE IMPL - BorrowServiceImpl.java
 * ============================================================
 *
 * Most complex business logic in the system.
 * Demonstrates:
 * - @Transactional for multi-step operations
 * - Business rule enforcement
 * - Entity state management
 * - Transaction isolation for concurrent borrows
 */
@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class BorrowServiceImpl implements BorrowService {

    private final BorrowRecordRepository borrowRecordRepository;
    private final BookRepository bookRepository;
    private final MemberRepository memberRepository;

    // Business rules
    private static final int DEFAULT_BORROW_DAYS = 14;
    private static final int BASIC_BORROW_LIMIT = 2;
    private static final int PREMIUM_BORROW_LIMIT = 5;
    private static final int VIP_BORROW_LIMIT = 10;

    /**
     * BORROW A BOOK - Core business operation
     *
     * Steps:
     * 1. Validate member exists and is active
     * 2. Validate book exists and is available
     * 3. Check member hasn't exceeded borrow limit
     * 4. Check member has no outstanding fines
     * 5. Create borrow record
     * 6. Decrement book available copies
     *
     * @Transactional ensures ALL steps succeed or ALL are rolled back
     * This prevents inconsistencies like: record created but copies not decremented
     */
    @Override
    public BorrowResponseDTO borrowBook(BorrowRequestDTO requestDTO) {
        log.info("Processing borrow: member={}, book={}", requestDTO.getMemberId(), requestDTO.getBookId());

        // STEP 1: Validate member
        Member member = memberRepository.findById(requestDTO.getMemberId())
                .orElseThrow(() -> new ResourceNotFoundException("Member", "id", requestDTO.getMemberId()));

        if (!member.isActive()) {
            throw new BusinessException("Member account is not active. Status: " + member.getStatus());
        }

        // STEP 2: Validate book
        Book book = bookRepository.findById(requestDTO.getBookId())
                .orElseThrow(() -> new ResourceNotFoundException("Book", "id", requestDTO.getBookId()));

        if (book.getAvailableCopies() <= 0) {
            throw new BusinessException("Book '" + book.getTitle() + "' is not available");
        }

        // STEP 3: Check if member already has this book borrowed
        boolean alreadyBorrowed = borrowRecordRepository
                .findByMemberIdAndBookIdAndStatus(member.getId(), book.getId(), BorrowRecord.BorrowStatus.BORROWED)
                .isPresent();

        if (alreadyBorrowed) {
            throw new BusinessException("Member already has this book borrowed");
        }

        // STEP 4: Check borrow limit based on membership type
        long currentBorrows = borrowRecordRepository
                .countByMemberIdAndStatus(member.getId(), BorrowRecord.BorrowStatus.BORROWED);

        int limit = getBorrowLimit(member.getMembershipType());
        if (currentBorrows >= limit) {
            throw new BusinessException(
                String.format("Borrow limit reached. %s membership allows %d books", 
                              member.getMembershipType(), limit));
        }

        // STEP 5: Check outstanding fines (can't borrow if fines > $10)
        if (member.getOutstandingFines() != null &&
            member.getOutstandingFines().compareTo(new java.math.BigDecimal("10.00")) > 0) {
            throw new BusinessException("Member has outstanding fines. Please pay fines before borrowing.");
        }

        // STEP 6: Create borrow record
        LocalDate borrowDate = LocalDate.now();
        LocalDate dueDate = requestDTO.getDueDate() != null ?
                requestDTO.getDueDate() :
                borrowDate.plusDays(DEFAULT_BORROW_DAYS);

        BorrowRecord borrowRecord = BorrowRecord.builder()
                .member(member)
                .book(book)
                .borrowDate(borrowDate)
                .dueDate(dueDate)
                .status(BorrowRecord.BorrowStatus.BORROWED)
                .notes(requestDTO.getNotes())
                .build();

        borrowRecord = borrowRecordRepository.save(borrowRecord);

        // STEP 7: Decrement available copies
        // Using @Modifying query for atomic update (prevents race condition)
        int updated = bookRepository.decrementAvailableCopies(book.getId());
        if (updated == 0) {
            // Concurrent borrow may have taken the last copy; rollback will occur
            throw new BusinessException("Book was just borrowed by another user. Please try again.");
        }

        // Update book status if no copies left
        book = bookRepository.findById(book.getId()).get();  // Refresh entity
        if (book.getAvailableCopies() == 0) {
            book.setStatus(Book.BookStatus.BORROWED);
            bookRepository.save(book);
        }

        log.info("Book borrowed successfully. Record ID: {}", borrowRecord.getId());
        return mapToResponse(borrowRecord);
    }

    /**
     * RETURN A BOOK
     *
     * Steps:
     * 1. Find borrow record
     * 2. Validate it's currently borrowed
     * 3. Calculate fine if overdue
     * 4. Update record status to RETURNED
     * 5. Increment book available copies
     */
    @Override
    public BorrowResponseDTO returnBook(Long borrowRecordId) {
        log.info("Processing return for borrow record ID: {}", borrowRecordId);

        BorrowRecord record = borrowRecordRepository.findById(borrowRecordId)
                .orElseThrow(() -> new ResourceNotFoundException("BorrowRecord", "id", borrowRecordId));

        if (!BorrowRecord.BorrowStatus.BORROWED.equals(record.getStatus()) &&
            !BorrowRecord.BorrowStatus.OVERDUE.equals(record.getStatus())) {
            throw new BusinessException("This book has already been returned");
        }

        // Calculate fine for late returns
        record.setReturnDate(LocalDate.now());
        record.setStatus(BorrowRecord.BorrowStatus.RETURNED);
        record.calculateFine();  // Method on entity

        // Update member's outstanding fines
        if (record.getFineAmount().compareTo(java.math.BigDecimal.ZERO) > 0) {
            Member member = record.getMember();
            member.setOutstandingFines(
                member.getOutstandingFines().add(record.getFineAmount())
            );
            memberRepository.save(member);
        }

        record = borrowRecordRepository.save(record);

        // Increment available copies
        bookRepository.incrementAvailableCopies(record.getBook().getId());

        // Update book status back to AVAILABLE
        Book book = bookRepository.findById(record.getBook().getId()).get();
        if (book.getStatus() == Book.BookStatus.BORROWED) {
            book.setStatus(Book.BookStatus.AVAILABLE);
            bookRepository.save(book);
        }

        log.info("Book returned. Fine: ${}", record.getFineAmount());
        return mapToResponse(record);
    }

    @Override
    @Transactional(readOnly = true)
    public BorrowResponseDTO getBorrowById(Long id) {
        BorrowRecord record = borrowRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("BorrowRecord", "id", id));
        return mapToResponse(record);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BorrowResponseDTO> getMemberBorrowHistory(Long memberId) {
        return borrowRecordRepository.findMemberHistoryWithDetails(memberId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BorrowResponseDTO> getOverdueRecords() {
        return borrowRecordRepository.findOverdueRecords(LocalDate.now())
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BorrowResponseDTO payFine(Long borrowRecordId) {
        BorrowRecord record = borrowRecordRepository.findById(borrowRecordId)
                .orElseThrow(() -> new ResourceNotFoundException("BorrowRecord", "id", borrowRecordId));

        if (record.getFineAmount().compareTo(java.math.BigDecimal.ZERO) == 0) {
            throw new BusinessException("No fine to pay for this record");
        }

        record.setFinePaid(true);

        // Deduct from member's outstanding fines
        Member member = record.getMember();
        member.setOutstandingFines(
            member.getOutstandingFines().subtract(record.getFineAmount())
                  .max(java.math.BigDecimal.ZERO)  // Don't go negative
        );
        memberRepository.save(member);

        record = borrowRecordRepository.save(record);
        return mapToResponse(record);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<BorrowResponseDTO> getMemberBorrows(Long memberId, Pageable pageable) {
        return borrowRecordRepository.findByMemberId(memberId, pageable)
                .map(this::mapToResponse);
    }

    // ===== HELPERS =====

    private int getBorrowLimit(Member.MembershipType type) {
        return switch (type) {  // Java 14+ switch expression
            case BASIC -> BASIC_BORROW_LIMIT;
            case PREMIUM, STUDENT -> PREMIUM_BORROW_LIMIT;
            case VIP, STAFF -> VIP_BORROW_LIMIT;
        };
    }

    private BorrowResponseDTO mapToResponse(BorrowRecord record) {
        return BorrowResponseDTO.builder()
                .id(record.getId())
                .memberId(record.getMember().getId())
                .memberName(record.getMember().getFirstName() + " " + record.getMember().getLastName())
                .memberCode(record.getMember().getMemberCode())
                .bookId(record.getBook().getId())
                .bookTitle(record.getBook().getTitle())
                .bookIsbn(record.getBook().getIsbn())
                .borrowDate(record.getBorrowDate())
                .dueDate(record.getDueDate())
                .returnDate(record.getReturnDate())
                .status(record.getStatus())
                .fineAmount(record.getFineAmount())
                .finePaid(record.getFinePaid())
                .overdue(record.isOverdue())
                .overdueDays(record.getOverdueDays())
                .createdAt(record.getCreatedAt())
                .build();
    }
}
