package com.library.serviceImpl;

import com.library.dto.MemberRequestDTO;
import com.library.dto.MemberResponseDTO;
import com.library.exception.DuplicateResourceException;
import com.library.exception.ResourceNotFoundException;
import com.library.model.Member;
import com.library.model.User;
import com.library.repository.BorrowRecordRepository;
import com.library.repository.MemberRepository;
import com.library.repository.UserRepository;
import com.library.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import com.library.model.BorrowRecord;

/**
 * ============================================================
 * SERVICE IMPL - MemberServiceImpl.java
 * ============================================================
 *
 * Demonstrates:
 * - PasswordEncoder (BCrypt hashing)
 * - Member code auto-generation
 * - Creating associated User account for member
 * - Pagination usage
 */
@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;
    private final UserRepository userRepository;
    private final BorrowRecordRepository borrowRecordRepository;
    private final PasswordEncoder passwordEncoder;  // Injected from SecurityConfig bean

    @Override
    public MemberResponseDTO createMember(MemberRequestDTO requestDTO) {
        log.info("Creating member with email: {}", requestDTO.getEmail());

        // Check for duplicate email
        if (memberRepository.existsByEmail(requestDTO.getEmail())) {
            throw new DuplicateResourceException("Member", "email", requestDTO.getEmail());
        }

        // Generate unique member code (e.g., LIB-2024-0001)
        String memberCode = generateMemberCode();

        // Build Member entity
        Member member = Member.builder()
                .memberCode(memberCode)
                .firstName(requestDTO.getFirstName())
                .lastName(requestDTO.getLastName())
                .email(requestDTO.getEmail())
                .phone(requestDTO.getPhone())
                .address(requestDTO.getAddress())
                .dateOfBirth(requestDTO.getDateOfBirth())
                .status(Member.MemberStatus.ACTIVE)
                .membershipType(Member.MembershipType.BASIC)
                .membershipExpiry(LocalDate.now().plusYears(1))  // 1 year membership
                .outstandingFines(BigDecimal.ZERO)
                .build();

        member = memberRepository.save(member);

        // Also create a User account for the member if password provided
        if (requestDTO.getPassword() != null && !requestDTO.getPassword().isBlank()) {
            User user = User.builder()
                    .email(requestDTO.getEmail())
                    .password(passwordEncoder.encode(requestDTO.getPassword()))  // BCrypt hash!
                    .role(User.Role.ROLE_MEMBER)
                    .member(member)
                    .build();
            userRepository.save(user);
        }

        log.info("Member created: {} ({})", member.getFullName(), member.getMemberCode());
        return mapToResponse(member, 0);
    }

    @Override
    @Transactional(readOnly = true)
    public MemberResponseDTO getMemberById(Long id) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member", "id", id));
        long activeBorrows = borrowRecordRepository.countByMemberIdAndStatus(id, BorrowRecord.BorrowStatus.BORROWED);
        return mapToResponse(member, (int) activeBorrows);
    }

    @Override
    @Transactional(readOnly = true)
    public MemberResponseDTO getMemberByCode(String memberCode) {
        Member member = memberRepository.findByMemberCode(memberCode)
                .orElseThrow(() -> new ResourceNotFoundException("Member", "memberCode", memberCode));
        long activeBorrows = borrowRecordRepository.countByMemberIdAndStatus(member.getId(), BorrowRecord.BorrowStatus.BORROWED);
        return mapToResponse(member, (int) activeBorrows);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<MemberResponseDTO> getAllMembers(Pageable pageable) {
        return memberRepository.findAll(pageable)
                .map(m -> mapToResponse(m, 0));  // Note: active borrow count not included in list for perf
    }

    @Override
    public MemberResponseDTO updateMember(Long id, MemberRequestDTO requestDTO) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member", "id", id));

        // Email uniqueness check (only if email changed)
        if (!member.getEmail().equalsIgnoreCase(requestDTO.getEmail()) &&
            memberRepository.existsByEmail(requestDTO.getEmail())) {
            throw new DuplicateResourceException("Member", "email", requestDTO.getEmail());
        }

        member.setFirstName(requestDTO.getFirstName());
        member.setLastName(requestDTO.getLastName());
        member.setEmail(requestDTO.getEmail());
        member.setPhone(requestDTO.getPhone());
        member.setAddress(requestDTO.getAddress());
        member.setDateOfBirth(requestDTO.getDateOfBirth());

        member = memberRepository.save(member);
        return mapToResponse(member, 0);
    }

    @Override
    public void deleteMember(Long id) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member", "id", id));
        memberRepository.delete(member);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<MemberResponseDTO> searchMembers(String keyword, Pageable pageable) {
        return memberRepository.searchMembers(keyword, pageable)
                .map(m -> mapToResponse(m, 0));
    }

    // ===== HELPERS =====

    private String generateMemberCode() {
        // Format: LIB-YYYY-XXXX (e.g., LIB-2024-0042)
        int year = java.time.Year.now().getValue();
        long count = memberRepository.count() + 1;
        return String.format("LIB-%d-%04d", year, count);
    }

    private MemberResponseDTO mapToResponse(Member member, int activeBorrowCount) {
        return MemberResponseDTO.builder()
                .id(member.getId())
                .memberCode(member.getMemberCode())
                .firstName(member.getFirstName())
                .lastName(member.getLastName())
                .fullName(member.getFullName())
                .email(member.getEmail())
                .phone(member.getPhone())
                .address(member.getAddress())
                .status(member.getStatus())
                .membershipType(member.getMembershipType())
                .membershipExpiry(member.getMembershipExpiry())
                .outstandingFines(member.getOutstandingFines())
                .createdAt(member.getCreatedAt())
                .activeBorrowCount(activeBorrowCount)
                .build();
    }
}
