package com.library.serviceImpl;

import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import com.library.exception.BusinessException;
import com.library.exception.DuplicateResourceException;
import com.library.exception.ResourceNotFoundException;
import com.library.model.Book;
import com.library.model.Category;
import com.library.repository.BookRepository;
import com.library.repository.CategoryRepository;
import com.library.service.BookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * ============================================================
 * SERVICE IMPLEMENTATION - BookServiceImpl.java
 * ============================================================
 *
 * KEY ANNOTATIONS:
 * ----------------
 * @Service - stereotype annotation:
 *   1. Marks this as a Spring-managed bean (component scanning picks it up)
 *   2. Spring injects it wherever BookService is @Autowired
 *   3. Semantically means "business logic layer"
 *
 * @Transactional - transaction management:
 *   - At CLASS level: all methods run in a transaction
 *   - At METHOD level: overrides class-level for that method
 *
 *   Transaction Properties:
 *   - propagation  = how transactions nest (default: REQUIRED = join existing or create new)
 *   - isolation    = how transactions see each other's uncommitted data
 *   - readOnly     = true → optimization hint for read-only queries (no dirty checking)
 *   - rollbackFor  = which exceptions trigger rollback (default: RuntimeException)
 *
 * @RequiredArgsConstructor (Lombok):
 *   Generates constructor for all FINAL fields
 *   Spring sees 1 constructor → uses it for CONSTRUCTOR INJECTION (preferred over @Autowired)
 *
 * @Slf4j (Lombok):
 *   Generates: private static final Logger log = LoggerFactory.getLogger(BookServiceImpl.class);
 *
 * DEPENDENCY INJECTION TYPES (exam topic):
 *   1. Constructor injection (RECOMMENDED):
 *      private final BookRepository repo;
 *      public BookServiceImpl(BookRepository repo) { this.repo = repo; }
 *   2. Setter injection: @Autowired void setRepo(BookRepository repo)
 *   3. Field injection: @Autowired private BookRepository repo; (AVOID - hard to test)
 */
@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class BookServiceImpl implements BookService {

    // Constructor injection via @RequiredArgsConstructor (fields must be final)
    private final BookRepository bookRepository;
    private final CategoryRepository categoryRepository;

    /**
     * CREATE a book
     *
     * @Transactional ensures:
     * - If categoryRepository.findById fails → no book is saved (atomic)
     * - If bookRepository.save fails → full rollback
     */
    @Override
    public BookResponseDTO createBook(BookRequestDTO requestDTO) {
        log.info("Creating book with ISBN: {}", requestDTO.getIsbn());

        // BUSINESS RULE: ISBN must be unique
        if (bookRepository.existsByIsbn(requestDTO.getIsbn())) {
            throw new DuplicateResourceException("Book", "ISBN", requestDTO.getIsbn());
        }

        // Map DTO → Entity
        Book book = mapRequestToEntity(requestDTO);

        // Set available copies = total copies on creation
        book.setAvailableCopies(requestDTO.getTotalCopies() != null ? requestDTO.getTotalCopies() : 1);

        // Persist to DB
        Book savedBook = bookRepository.save(book);
        log.info("Book created with ID: {}", savedBook.getId());

        // Map Entity → Response DTO
        return mapEntityToResponse(savedBook);
    }

    /**
     * READ - get by ID
     *
     * @Transactional(readOnly = true):
     * - Tells Hibernate: don't track changes (no dirty checking)
     * - Database: can optimize reads (no write locks needed)
     * - Slightly better performance for SELECT-only operations
     *
     * orElseThrow() - Optional chaining:
     * If empty → execute the lambda → throw exception
     */
    @Override
    @Transactional(readOnly = true)
    public BookResponseDTO getBookById(Long id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book", "id", id));
        return mapEntityToResponse(book);
    }

    /**
     * READ - paginated list
     *
     * Pageable is created by Spring MVC from request parameters:
     * GET /api/books?page=0&size=10&sort=title,asc
     *
     * Page<T> contains:
     * - content: List<T> (the actual data)
     * - totalElements: total count in DB
     * - totalPages: total page count
     * - number: current page index (0-based)
     * - size: page size
     */
    @Override
    @Transactional(readOnly = true)
    public Page<BookResponseDTO> getAllBooks(Pageable pageable) {
        // map() on Page transforms content while preserving pagination metadata
        return bookRepository.findAll(pageable)
                .map(this::mapEntityToResponse);  // method reference
    }

    /**
     * UPDATE a book
     *
     * Two approaches:
     * 1. Find entity, modify fields, save → Hibernate detects changes (dirty checking)
     * 2. Use @Modifying @Query for bulk updates
     *
     * Here we use approach 1 (cleaner for partial updates)
     */
    @Override
    public BookResponseDTO updateBook(Long id, BookRequestDTO requestDTO) {
        log.info("Updating book ID: {}", id);

        // 1. Find existing book (throws 404 if not found)
        Book existingBook = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book", "id", id));

        // 2. Check ISBN uniqueness (if ISBN is being changed)
        if (!existingBook.getIsbn().equals(requestDTO.getIsbn()) &&
            bookRepository.existsByIsbn(requestDTO.getIsbn())) {
            throw new DuplicateResourceException("Book", "ISBN", requestDTO.getIsbn());
        }

        // 3. Update fields
        existingBook.setTitle(requestDTO.getTitle());
        existingBook.setAuthor(requestDTO.getAuthor());
        existingBook.setIsbn(requestDTO.getIsbn());
        existingBook.setPublisher(requestDTO.getPublisher());
        existingBook.setPublishedDate(requestDTO.getPublishedDate());
        existingBook.setGenre(requestDTO.getGenre());
        existingBook.setDescription(requestDTO.getDescription());
        existingBook.setPrice(requestDTO.getPrice());

        // Update category if provided
        if (requestDTO.getCategoryId() != null) {
            Category category = categoryRepository.findById(requestDTO.getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", requestDTO.getCategoryId()));
            existingBook.setCategory(category);
        }

        // Update copies (adjust available accordingly)
        if (requestDTO.getTotalCopies() != null) {
            int diff = requestDTO.getTotalCopies() - existingBook.getTotalCopies();
            existingBook.setTotalCopies(requestDTO.getTotalCopies());
            existingBook.setAvailableCopies(Math.max(0, existingBook.getAvailableCopies() + diff));
        }

        // 4. Save - Hibernate dirty checking will auto-detect changes and issue UPDATE SQL
        // But explicit save() is good practice
        Book updatedBook = bookRepository.save(existingBook);
        return mapEntityToResponse(updatedBook);
    }

    /**
     * DELETE a book
     *
     * SOFT DELETE vs HARD DELETE:
     * - Hard delete: DELETE FROM books WHERE id = ? (implemented here)
     * - Soft delete: UPDATE books SET deleted = true (common in production)
     *   Soft delete preserves history, hard delete removes data permanently
     */
    @Override
    public void deleteBook(Long id) {
        log.info("Deleting book ID: {}", id);

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book", "id", id));

        // Business rule: can't delete a book that's currently borrowed
        if (book.getAvailableCopies() < book.getTotalCopies()) {
            throw new BusinessException("Cannot delete book that has copies currently borrowed");
        }

        bookRepository.delete(book);
        log.info("Book deleted: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookResponseDTO> searchBooks(String keyword) {
        return bookRepository.searchBooks(keyword)
                .stream()
                .map(this::mapEntityToResponse)    // Stream.map() transforms each element
                .collect(Collectors.toList());      // Terminal operation: collect to List
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookResponseDTO> getBooksByCategory(Long categoryId) {
        // Verify category exists
        categoryRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", categoryId));

        return bookRepository.findByCategoryId(categoryId)
                .stream()
                .map(this::mapEntityToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookResponseDTO> getAvailableBooks() {
        return bookRepository.findByAvailableCopiesGreaterThan(0)
                .stream()
                .map(this::mapEntityToResponse)
                .collect(Collectors.toList());
    }

    // ===== PRIVATE HELPER METHODS (Entity ↔ DTO mapping) =====

    /**
     * Map RequestDTO → Entity
     * This is manual mapping (alternative: use ModelMapper or MapStruct)
     *
     * Manual mapping:
     *   + Explicit and clear
     *   + No magic/reflection
     *   - Verbose for many fields
     *
     * ModelMapper:
     *   + Less code
     *   - Can miss mismatched field names silently
     *
     * MapStruct (best for production):
     *   + Type-safe, compile-time checked
     *   + Very fast (no reflection at runtime)
     *   - Requires setup
     */
    private Book mapRequestToEntity(BookRequestDTO dto) {
        Book book = Book.builder()
                .title(dto.getTitle())
                .author(dto.getAuthor())
                .isbn(dto.getIsbn())
                .publisher(dto.getPublisher())
                .publishedDate(dto.getPublishedDate())
                .genre(dto.getGenre())
                .description(dto.getDescription())
                .price(dto.getPrice())
                .totalCopies(dto.getTotalCopies() != null ? dto.getTotalCopies() : 1)
                .build();

        // Set category if provided
        if (dto.getCategoryId() != null) {
            Category category = categoryRepository.findById(dto.getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", dto.getCategoryId()));
            book.setCategory(category);
        }

        return book;
    }

    /**
     * Map Entity → ResponseDTO
     * Using builder pattern for clean construction
     */
    private BookResponseDTO mapEntityToResponse(Book book) {
        BookResponseDTO.BookResponseDTOBuilder builder = BookResponseDTO.builder()
                .id(book.getId())
                .title(book.getTitle())
                .author(book.getAuthor())
                .isbn(book.getIsbn())
                .publisher(book.getPublisher())
                .publishedDate(book.getPublishedDate())
                .genre(book.getGenre())
                .status(book.getStatus())
                .totalCopies(book.getTotalCopies())
                .availableCopies(book.getAvailableCopies())
                .description(book.getDescription())
                .price(book.getPrice())
                .createdAt(book.getCreatedAt())
                .updatedAt(book.getUpdatedAt());

        // Safely handle null category (book may not have a category)
        if (book.getCategory() != null) {
            builder.categoryId(book.getCategory().getId())
                   .categoryName(book.getCategory().getName());
        }

        return builder.build();
    }
}
