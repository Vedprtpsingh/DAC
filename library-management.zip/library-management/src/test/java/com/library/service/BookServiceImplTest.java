package com.library.service;

import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import com.library.exception.DuplicateResourceException;
import com.library.exception.ResourceNotFoundException;
import com.library.model.Book;
import com.library.repository.BookRepository;
import com.library.repository.CategoryRepository;
import com.library.serviceImpl.BookServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * ============================================================
 * UNIT TEST - BookServiceImplTest.java
 * ============================================================
 *
 * KEY TESTING CONCEPTS (EXAM TOPICS):
 * ------------------------------------
 * @ExtendWith(MockitoExtension.class) - enables Mockito annotations in JUnit 5
 *
 * @Mock - creates a fake/mock object (doesn't call real implementation)
 *   Used for dependencies we don't want to test (BookRepository here)
 *
 * @InjectMocks - creates the REAL object under test and injects @Mock fields into it
 *   This is the SUT (System/Subject Under Test)
 *
 * UNIT TEST vs INTEGRATION TEST:
 *   - Unit test: tests ONE class in isolation, dependencies are mocked
 *     (this file - fast, no Spring context, no DB)
 *   - Integration test: tests multiple layers together, often with real/test DB
 *     (see BookControllerIntegrationTest)
 *
 * MOCKITO METHODS:
 *   when(mock.method()).thenReturn(value)  → stub a return value
 *   when(mock.method()).thenThrow(ex)      → stub an exception
 *   verify(mock).method()                  → assert method was called
 *   verify(mock, times(n)).method()        → assert called n times
 *   verify(mock, never()).method()         → assert never called
 *   any(), anyLong(), eq(value)            → argument matchers
 *
 * AAA PATTERN (test structure):
 *   Arrange - set up test data and mocks
 *   Act     - call the method under test
 *   Assert  - verify the result
 */
@ExtendWith(MockitoExtension.class)
class BookServiceImplTest {

    @Mock
    private BookRepository bookRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private BookServiceImpl bookService;

    private Book sampleBook;
    private BookRequestDTO sampleRequestDTO;

    /**
     * @BeforeEach - runs before EVERY test method
     * Used to set up fresh test data (avoid test pollution between tests)
     */
    @BeforeEach
    void setUp() {
        sampleBook = Book.builder()
                .id(1L)
                .title("Clean Code")
                .author("Robert C. Martin")
                .isbn("9780132350884")
                .totalCopies(3)
                .availableCopies(3)
                .price(new BigDecimal("45.99"))
                .status(Book.BookStatus.AVAILABLE)
                .build();

        sampleRequestDTO = BookRequestDTO.builder()
                .title("Clean Code")
                .author("Robert C. Martin")
                .isbn("9780132350884")
                .totalCopies(3)
                .price(new BigDecimal("45.99"))
                .build();
    }

    @Test
    void createBook_Success_WhenIsbnIsUnique() {
        // ARRANGE: stub repository calls
        when(bookRepository.existsByIsbn(sampleRequestDTO.getIsbn())).thenReturn(false);
        when(bookRepository.save(any(Book.class))).thenReturn(sampleBook);

        // ACT: call the method under test
        BookResponseDTO result = bookService.createBook(sampleRequestDTO);

        // ASSERT: verify the outcome
        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo("Clean Code");
        assertThat(result.getIsbn()).isEqualTo("9780132350884");

        // Verify save() was called exactly once
        verify(bookRepository, times(1)).save(any(Book.class));
    }

    @Test
    void createBook_ThrowsException_WhenIsbnAlreadyExists() {
        // ARRANGE: simulate duplicate ISBN
        when(bookRepository.existsByIsbn(sampleRequestDTO.getIsbn())).thenReturn(true);

        // ACT & ASSERT: expect exception to be thrown
        assertThrows(DuplicateResourceException.class, () -> {
            bookService.createBook(sampleRequestDTO);
        });

        // Verify save() was NEVER called (since we threw before reaching it)
        verify(bookRepository, never()).save(any(Book.class));
    }

    @Test
    void getBookById_Success_WhenBookExists() {
        // ARRANGE
        when(bookRepository.findById(1L)).thenReturn(Optional.of(sampleBook));

        // ACT
        BookResponseDTO result = bookService.getBookById(1L);

        // ASSERT
        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getTitle()).isEqualTo("Clean Code");
    }

    @Test
    void getBookById_ThrowsResourceNotFoundException_WhenBookDoesNotExist() {
        // ARRANGE: empty Optional simulates "not found"
        when(bookRepository.findById(99L)).thenReturn(Optional.empty());

        // ACT & ASSERT
        ResourceNotFoundException exception = assertThrows(
                ResourceNotFoundException.class,
                () -> bookService.getBookById(99L)
        );

        assertThat(exception.getMessage()).contains("99");
    }

    @Test
    void deleteBook_ThrowsBusinessException_WhenCopiesAreBorrowed() {
        // ARRANGE: book has 1 copy borrowed (availableCopies < totalCopies)
        sampleBook.setAvailableCopies(2);
        sampleBook.setTotalCopies(3);
        when(bookRepository.findById(1L)).thenReturn(Optional.of(sampleBook));

        // ACT & ASSERT
        assertThrows(com.library.exception.BusinessException.class, () -> {
            bookService.deleteBook(1L);
        });

        verify(bookRepository, never()).delete(any(Book.class));
    }

    @Test
    void deleteBook_Success_WhenAllCopiesAvailable() {
        // ARRANGE: all copies available, safe to delete
        when(bookRepository.findById(1L)).thenReturn(Optional.of(sampleBook));

        // ACT
        bookService.deleteBook(1L);

        // ASSERT: verify delete was called
        verify(bookRepository, times(1)).delete(sampleBook);
    }
}
