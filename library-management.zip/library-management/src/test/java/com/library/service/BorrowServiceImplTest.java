package com.library.service;

import com.library.dto.BorrowRequestDTO;
import com.library.dto.BorrowResponseDTO;
import com.library.exception.BusinessException;
import com.library.model.Book;
import com.library.model.BorrowRecord;
import com.library.model.Member;
import com.library.repository.BookRepository;
import com.library.repository.BorrowRecordRepository;
import com.library.repository.MemberRepository;
import com.library.serviceImpl.BorrowServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * ============================================================
 * UNIT TEST - BorrowServiceImplTest.java
 * ============================================================
 * Tests the most business-logic-heavy service in the app.
 * Demonstrates testing of MULTIPLE business rules and edge cases.
 */
@ExtendWith(MockitoExtension.class)
class BorrowServiceImplTest {

    @Mock
    private BorrowRecordRepository borrowRecordRepository;
    @Mock
    private BookRepository bookRepository;
    @Mock
    private MemberRepository memberRepository;

    @InjectMocks
    private BorrowServiceImpl borrowService;

    private Member activeMember;
    private Book availableBook;
    private BorrowRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        activeMember = Member.builder()
                .id(1L)
                .memberCode("LIB-2024-0001")
                .firstName("John")
                .lastName("Doe")
                .status(Member.MemberStatus.ACTIVE)
                .membershipType(Member.MembershipType.BASIC)
                .outstandingFines(BigDecimal.ZERO)
                .build();

        availableBook = Book.builder()
                .id(1L)
                .title("Clean Code")
                .isbn("9780132350884")
                .totalCopies(3)
                .availableCopies(2)
                .status(Book.BookStatus.AVAILABLE)
                .build();

        requestDTO = new BorrowRequestDTO(1L, 1L, null, null);
    }

    @Test
    void borrowBook_Success_WhenAllConditionsMet() {
        // ARRANGE
        when(memberRepository.findById(1L)).thenReturn(Optional.of(activeMember));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(availableBook));
        when(borrowRecordRepository.findByMemberIdAndBookIdAndStatus(1L, 1L, BorrowRecord.BorrowStatus.BORROWED))
                .thenReturn(Optional.empty());
        when(borrowRecordRepository.countByMemberIdAndStatus(1L, BorrowRecord.BorrowStatus.BORROWED))
                .thenReturn(0L);
        when(borrowRecordRepository.save(any(BorrowRecord.class))).thenAnswer(invocation -> {
            BorrowRecord record = invocation.getArgument(0);
            record.setId(100L);
            return record;
        });
        when(bookRepository.decrementAvailableCopies(1L)).thenReturn(1);
        // findById called again to refresh book state after decrement
        Book bookAfterDecrement = Book.builder()
                .id(1L).title("Clean Code").isbn("9780132350884")
                .totalCopies(3).availableCopies(1).status(Book.BookStatus.AVAILABLE).build();
        when(bookRepository.findById(1L))
                .thenReturn(Optional.of(availableBook))
                .thenReturn(Optional.of(bookAfterDecrement));

        // ACT
        BorrowResponseDTO result = borrowService.borrowBook(requestDTO);

        // ASSERT
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(BorrowRecord.BorrowStatus.BORROWED);
        verify(bookRepository, times(1)).decrementAvailableCopies(1L);
    }

    @Test
    void borrowBook_ThrowsException_WhenBookNotAvailable() {
        // ARRANGE: no copies available
        availableBook.setAvailableCopies(0);
        when(memberRepository.findById(1L)).thenReturn(Optional.of(activeMember));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(availableBook));

        // ACT & ASSERT
        BusinessException ex = assertThrows(BusinessException.class,
                () -> borrowService.borrowBook(requestDTO));

        assertThat(ex.getMessage()).contains("not available");
        verify(borrowRecordRepository, never()).save(any());
    }

    @Test
    void borrowBook_ThrowsException_WhenMemberInactive() {
        // ARRANGE
        activeMember.setStatus(Member.MemberStatus.SUSPENDED);
        when(memberRepository.findById(1L)).thenReturn(Optional.of(activeMember));

        // ACT & ASSERT
        assertThrows(BusinessException.class, () -> borrowService.borrowBook(requestDTO));
    }

    @Test
    void borrowBook_ThrowsException_WhenBorrowLimitReached() {
        // ARRANGE: BASIC membership limit is 2 books
        when(memberRepository.findById(1L)).thenReturn(Optional.of(activeMember));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(availableBook));
        when(borrowRecordRepository.findByMemberIdAndBookIdAndStatus(1L, 1L, BorrowRecord.BorrowStatus.BORROWED))
                .thenReturn(Optional.empty());
        // Member already has 2 books borrowed (BASIC limit)
        when(borrowRecordRepository.countByMemberIdAndStatus(1L, BorrowRecord.BorrowStatus.BORROWED))
                .thenReturn(2L);

        // ACT & ASSERT
        BusinessException ex = assertThrows(BusinessException.class,
                () -> borrowService.borrowBook(requestDTO));

        assertThat(ex.getMessage()).contains("limit");
    }

    @Test
    void returnBook_CalculatesFine_WhenOverdue() {
        // ARRANGE: borrow record that's overdue by 5 days
        BorrowRecord overdueRecord = BorrowRecord.builder()
                .id(1L)
                .member(activeMember)
                .book(availableBook)
                .borrowDate(LocalDate.now().minusDays(19))
                .dueDate(LocalDate.now().minusDays(5))  // 5 days overdue
                .status(BorrowRecord.BorrowStatus.BORROWED)
                .fineAmount(BigDecimal.ZERO)
                .build();

        when(borrowRecordRepository.findById(1L)).thenReturn(Optional.of(overdueRecord));
        when(borrowRecordRepository.save(any(BorrowRecord.class))).thenAnswer(inv -> inv.getArgument(0));
        when(bookRepository.findById(1L)).thenReturn(Optional.of(availableBook));
        when(memberRepository.save(any(Member.class))).thenReturn(activeMember);

        // ACT
        BorrowResponseDTO result = borrowService.returnBook(1L);

        // ASSERT: fine should be calculated (5 days * $0.50 = $2.50)
        assertThat(result.getStatus()).isEqualTo(BorrowRecord.BorrowStatus.RETURNED);
        assertThat(result.getFineAmount()).isGreaterThan(BigDecimal.ZERO);
    }
}
