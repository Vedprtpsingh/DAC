package com.library.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.library.dto.BookRequestDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * ============================================================
 * INTEGRATION TEST - BookControllerIntegrationTest.java
 * ============================================================
 *
 * KEY CONCEPTS (EXAM TOPICS):
 * ----------------------------
 * @SpringBootTest - loads the FULL Spring application context
 *   (unlike unit tests which only test one class in isolation)
 *   webEnvironment = MOCK (default) - doesn't start a real server, uses MockMvc
 *
 * @AutoConfigureMockMvc - auto-configures MockMvc bean for testing HTTP layer
 *   without starting an actual HTTP server (faster than real HTTP calls)
 *
 * MockMvc - simulates HTTP requests to test controllers end-to-end:
 *   mockMvc.perform(get("/api/books"))
 *          .andExpect(status().isOk())
 *          .andExpect(jsonPath("$.data").isArray());
 *
 * @WithMockUser - simulates an authenticated user for the test
 *   roles = {"ADMIN"} → grants ROLE_ADMIN authority
 *   Used to test @PreAuthorize-protected endpoints
 *
 * jsonPath() - JSONPath expressions to assert on JSON response body:
 *   $.data.title         → data.title field
 *   $.data[0].id         → first element's id in array
 *   $.success            → top-level success field
 *
 * @ActiveProfiles("test") - uses application-test.properties if present
 *   (commonly points to an H2 in-memory DB instead of MySQL for fast tests)
 *
 * NOTE: This test uses the actual MySQL datasource by default unless an
 * application-test.properties with H2 is added. For pure unit testing of
 * business logic, prefer the Mockito-based tests (see BookServiceImplTest).
 */
@SpringBootTest
@AutoConfigureMockMvc
class BookControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;  // Spring Boot auto-configures Jackson's ObjectMapper

    /**
     * Test: GET /api/books is publicly accessible (no auth required)
     */
    @Test
    void getAllBooks_ReturnsOk_WithoutAuthentication() throws Exception {
        mockMvc.perform(get("/api/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    /**
     * Test: GET /api/books/search requires keyword param
     */
    @Test
    void searchBooks_ReturnsOk_WithKeywordParam() throws Exception {
        mockMvc.perform(get("/api/books/search").param("keyword", "Clean"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    /**
     * Test: POST /api/books WITHOUT authentication should be FORBIDDEN/UNAUTHORIZED
     * Verifies Spring Security is correctly protecting the endpoint
     */
    @Test
    void createBook_ReturnsUnauthorized_WithoutAuthentication() throws Exception {
        BookRequestDTO request = BookRequestDTO.builder()
                .title("Test Book")
                .author("Test Author")
                .isbn("1234567890123")
                .totalCopies(1)
                .price(new BigDecimal("10.00"))
                .build();

        mockMvc.perform(post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized());
    }

    /**
     * Test: POST /api/books WITH librarian role should succeed (201 Created)
     * @WithMockUser simulates authentication without needing a real JWT
     */
    @Test
    @WithMockUser(roles = "LIBRARIAN")
    void createBook_ReturnsCreated_WithLibrarianRole() throws Exception {
        BookRequestDTO request = BookRequestDTO.builder()
                .title("Integration Test Book")
                .author("Test Author")
                .isbn("9999999999999")
                .totalCopies(2)
                .price(new BigDecimal("20.00"))
                .build();

        mockMvc.perform(post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.title").value("Integration Test Book"));
    }

    /**
     * Test: POST /api/books with INVALID data should return 400 with validation errors
     */
    @Test
    @WithMockUser(roles = "LIBRARIAN")
    void createBook_ReturnsBadRequest_WithInvalidData() throws Exception {
        // Missing required fields (title, author, isbn)
        BookRequestDTO invalidRequest = BookRequestDTO.builder().build();

        mockMvc.perform(post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.errors").exists());
    }

    /**
     * Test: GET /api/books/{id} with non-existent ID returns 404
     */
    @Test
    void getBookById_ReturnsNotFound_WhenBookDoesNotExist() throws Exception {
        mockMvc.perform(get("/api/books/999999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false));
    }

    /**
     * Test: DELETE without ADMIN role should be FORBIDDEN
     */
    @Test
    @WithMockUser(roles = "LIBRARIAN")  // Librarian, not Admin
    void deleteBook_ReturnsForbidden_WithoutAdminRole() throws Exception {
        mockMvc.perform(delete("/api/books/1"))
                .andExpect(status().isForbidden());
    }
}
